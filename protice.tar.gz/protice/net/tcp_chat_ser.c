#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/wait.h>
#include <unistd.h>
#include <arpa/inet.h>
#define MAXBUF 1024


int main(int argc,  char *argv[])
{
    int pid;
    int sockfd, new_fd;

    unsigned int myport, lisnum;
    struct sockaddr_in my_addr, their_addr;
    socklen_t len;
    char buf[MAXBUF+1];

    if(argv[2])
        myport = atoi(argv[2]);
    else
        myport = 8090;
    if(argv[3])
        lisnum = atoi(argv[3]);
    else
        lisnum = 5;

    if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("socket");
        exit(1);
    }

    bzero(&my_addr, sizeof(my_addr));
    my_addr.sin_family = AF_INET;               //地址协议
    my_addr.sin_port = htons(myport);           //地址端口
    if(argv[1])
        //将点分十进制字符串转换为网络顺序ip地址
        my_addr.sin_addr.s_addr = inet_addr(argv[1]);
    else
        my_addr.sin_addr.s_addr = INADDR_ANY;
    if(bind(sockfd, (struct sockaddr*)&my_addr, sizeof(struct sockaddr)) == -1)
    {
        perror("bind");
        exit(1);
    }

    if(listen(sockfd, lisnum) == -1)
    {
        perror("listen");
        exit(1);
    }
    printf("wait for connect\n");
    len = sizeof(struct sockaddr);
    if((new_fd = accept(sockfd, (struct sockaddr*)&their_addr, &len)) == -1)
    {
        perror("accept");
        exit(1);
    }
    else
        printf("server:got connection from %s, port %d, socket %d\n",
        inet_ntoa(their_addr.sin_addr), ntohs(their_addr.sin_port), new_fd);

    while(1)
    {
        printf("newfd = %d\n", new_fd);
        bzero(buf, MAXBUF+1);
        printf("input the message to send:");
        fgets(buf, MAXBUF, stdin);
        if(!strncasecmp(buf, "quit", 4))
        {
            printf("i will close the connect！\n");
            break;
        }
        len = send(new_fd, buf, strlen(buf)-1, 0);
        if(len > 0)
        {
            printf("message:%s\t send sucessful, send %dbyte!\n", buf, len);
        }
        else
        {
            printf("message '%s' send failedure! errno code is %d, errno message is '%s' \n", buf, errno, strerror(errno));
            break;
        }
        bzero(buf, MAXBUF+1);
        len = recv(new_fd, buf, MAXBUF, 0);
        if(len > 0)
            printf("message recv successful:%s, %dByte recv\n", buf, len);

        else
        {
            if(len < 0)
                printf("recv failure! errno code is %d, errno message is '%s' \n", errno, strerror(errno));
            else
                printf("the other one close quit\n");
            break;
        }
    }
    close(new_fd);
    close(sockfd);
    return 0;
}
