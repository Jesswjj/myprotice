#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

pthread_mutex_t mutex;

/************************************************************************
函数名称：   void *client_process(void *arg)
函数功能：   线程函数,处理客户信息
函数参数：   已连接套接字
函数返回：   无
************************************************************************/
void *client_process(void* arg)
{
    int recv_len = 0;
    char recv_buf[1024] = "";
    int connfd = *(int *)arg;

    pthread_mutex_unlock(&mutex);

    while((recv_len = recv(connfd, recv_buf, sizeof(recv_buf), 0)) > 0)
    {
        printf("recv_buf:%s\n", recv_buf);
        send(connfd, "I have rcv", 11, 0);
    }

    printf("client closed!\n");
    close(connfd);

    return NULL;
}

//===============================================================
// 语法格式：    void main(void)
// 实现功能：    主函数，建立一个TCP并发服务器
// 入口参数：    无
// 出口参数：    无
//===============================================================


int main()
{
    int sockfd = 0;
    int connfd = 0;
    int err_log = 0;

    struct sockaddr_in my_addr;
    unsigned short port = 8090;
    pthread_t thread_id;

    pthread_mutex_init(&mutex, NULL);

    printf("TCP server started at port %d\n", port);

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sockfd < 0)
    {
        perror("socket error");
        exit(1);
    }

    bzero(&my_addr, sizeof(my_addr));
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(port);
    my_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    printf("binding server to port %d\n", port);

    err_log = bind(sockfd, (struct sockaddr*)&my_addr, sizeof(my_addr));
    if(err_log != 0)
    {
        perror("bind");
        close(sockfd);
        exit(1);
    }

    err_log = listen(sockfd, 10);
    if(err_log != 0)
    {
        perror("listen");
        close(sockfd);
        exit(1);
    }

    printf("Waiting client...\n");

    char cli_ip[INET_ADDRSTRLEN] = "";
    struct sockaddr_in client_addr;
    socklen_t cliaddr_len = sizeof(client_addr);

    while(1)
    {
        pthread_mutex_lock(&mutex);

        connfd = accept(sockfd, (struct sockaddr*)&client_addr, &cliaddr_len);
        if(connfd < 0)
        {
            perror("accept this time");
            continue;
        }

        inet_ntop(AF_INET, &client_addr.sin_addr, cli_ip, INET_ADDRSTRLEN);
        printf("------------------------------------------\n");
        printf("client ip=%s, port=%d\n", cli_ip, ntohs(client_addr.sin_port));

        if(connfd > 0)
        {
            pthread_create(&thread_id, NULL, (void *)client_process, (void*)&connfd);
            pthread_detach(thread_id);
        }
    }

    close(sockfd);

    return 0;
}
