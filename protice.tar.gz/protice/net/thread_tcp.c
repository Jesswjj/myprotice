#include <stdio.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <pthread.h>

/************************************************************************
函数名称：   void *client_process(void *arg)
函数功能：   线程函数,处理客户信息
函数参数：   已连接套接字
函数返回：   无
************************************************************************/


void *client_process(void *arg)
{
    int recv_len = 0;
    char recv_buf[1024] = "";
    int connfd = (int)arg;

    // 解锁，pthread_mutex_lock()唤醒，不阻塞
    pthread_mutex_unlock(&mutex);
    // 接收数据
    while((recv_len = recv(connfd, recv_buf, sizeof(recv_buf), 0)) > 0)
    {
        printf("recv_buf:%s\n", recv_buf);// 打印数据
        send(connfd, "I have rcv", 11, 0);// 给客户端回数据
    }

    printf("client closed\n");
    close(connfd);//关闭已连接套接字

}

//===============================================================
// 语法格式：    void main(void)
// 实现功能：    主函数，建立一个TCP并发服务器
// 入口参数：    无
// 出口参数：    无
//===============================================================

int main(int argc, char *argv[])
{
    int sockfd = 0;
    int connfd = 0;
    int err_log = 0;

    struct sockaddr_in my_addr;
    unsigned short port = 8090;
    pthread_t thread_id;

    pthread_mutex_init(&mutex, NULL); // 初始化互斥锁，互斥锁默认是打开的

    printf("TCP Server started at port %d\n", port);

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sockfd < 0)
    {
        perror("socket error");
        exit(1);
    }

    bzero(&my_addr, sizeof(my_addr));
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(port);
    my_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    printf("Bind server to port %d\n", port);

    err_log = bind(sockfd, (struct sockaddr*)&my_addr, sizeof(my_addr));
    if(err_log != 0)
    {
        perror("bind");
        close(sockfd);
        exit(1);
    }

    err_log = listen(sockfd, 10);
    if(err_log != 0)
    {
        perror("listen");
        close(sockfd);
        exit(1);
    }

    printf("waiting client...\n");


    while(1)
    {
        char cli_ip[INET_ADDRSTRLEN] = "";     // 用于保存客户端IP地址
        struct sockaddr_in client_addr;        // 用于保存客户端地址
        socklen_t cliaddr_len = NULL;   // 必须初始化!!!

        // 上锁，在没有解锁之前，pthread_mutex_lock()会阻塞
        pthread_mutex_lock(&mutex);
        //获得一个已经建立的连接
        connfd = accept(sockfd, (struct sockaddr*)&client_addr, &cliaddr_len);
        if(connfd < 0)
        {
            perror("accept this time");
            continue;
        }

        inet_ntop(AF_INET, &client_addr.sin_addr, cli_ip, INET_ADDRSTRLEN);
        printf("----------------------------------------------------\n");
        printf("client ip = %s, port = %d\n", cli_ip, ntohs(client_addr.sin_port));

        if(connfd > 0)
        {
            pthread_create(&thread_id, NULL, (void*)client_process, (void*)connfd);
            pthread_detach(thread_id);
        }
    }
    close(sockfd);

    return 0;
}
