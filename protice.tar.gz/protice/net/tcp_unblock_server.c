#include <sys/types.h>
#include <sys/socket.h>
#include <stdio.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>

#define BUFSIZE 128

int main(int argc, char* argv[])
{
    int server_sockfd, client_sockfd;
    int server_len;
    socklen_t client_len;
    struct sockaddr_in server_addr;
    struct sockaddr_in client_addr;

    int i, byet;
    char char_send[BUFSIZE];

    server_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    server_addr.sin_family = AF_INET;
    inet_pton(AF_INET, "192.168.2.110", server_addr.sin_addr.s_addr);
    server_addr.sin_port = htons(8090);

    server_len = sizeof(server_addr);

    bind(server_sockfd, (struct sockaddr*)&server_addr, server_len);
    listen(server_sockfd, 5);

    printf("server waiting for connect\n");
    client_len = sizeof(client_addr);
    client_sockfd = accept(server_sockfd, (struct sockaddr*)&client_addr, client_len);

    for(i = 0; i < 5; i++)
    {
        memset(char_send, '\0', BUFSIZE);
        printf("input message to send:");
        fgets(char_send, BUFSIZE, stdin);

        if((byte = send(client_sockfd, char_send, strlen(char_send), 0)) == -1)
        {
            perror("send");
            exit(1);
        }

        memset(char_send, '\0', BUFSIZE);
        byte = recv(client_sockfd, char_send, BUFSIZE, MSG_DONTWAIT);
        if(byte > 0)
        {
            printf("get %d message:%s", byte, char_send);
            byte = 0;
        }
        else if(bytes < 0)
        {
            if(errno == EAGAIN)
            {
                errno = 0;
                continue;
            }
            else
            {
                perror("recv");
                exit(1);
            }
        }
    }
    shutdown(client_sockfd, 2);
    shutdown(server_sockfd, 2);
}
