#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>

int main(int argc, char **argv)
{
    int sock[2];
    int pid;
    int i;
    static char buf[128];
    if(socketpair(AF_UNIX, SOCK_STREAM, 0, sock) < 0)
    {
        perror("socketpair");
        exit(1);
    }
    if((pid = fork()) == -1)
    {
        perror("fork");
        exit(1);
    }
    else if(pid == 0)
    {
        close(sock[1]);
        for(i = 0; i < 10; i= i+2)
        {
            sleep(1);
            sprintf(buf, "child, %d", i);
            write(sock[0], buf, sizeof(buf));
            read(sock[0], buf, sizeof(buf));
            printf("child receive data from parent %s\n", buf);
        }
        close(sock[0]);
        exit(1);
    }
    else
    {
        sleep(1);
        close(sock[0]);
        for(i = 1; i < 10; i = i+2)
        {
            read(sock[1], buf, sizeof(buf));
            printf("parent receive data from child %s\n", buf);
            sprintf(buf, "parent, %d", i);
            write(sock[1], buf, sizeof(buf));
        }
        close(sock[1]);
        exit(1);

    }
    return 0;
}
