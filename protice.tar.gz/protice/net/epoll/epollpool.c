#include <sys/socket.h>
#include <sys/epoll.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

#include <pthread.h>

#define MAXLINE 10
#define OPEN_MAX 100
#define LISENQ 20
#define SERV_PORT 9000
#define INFTIME 1000

struct task         //线程池任务队列结构体
{
    int fd;         //需要读写的文件描述符
    struct task *next;  //下一个任务

};

struct user_data    //用于读写两个方面传递参数
{
    int fd;
    unsigned int n_size;
    char line[MAXLINE];
};

void *readtask(void *args);     //读线程的任务函数
void *writetask(void *args);    //写线程的任务函数
struct epoll_event ev, events[20];

int epfd;

pthread_mutex_t mutex;      //互斥锁
pthread_cond_t condl;       //条件变量

struct task *readhead = NULL, *readtail = NULL, *writehead = NULL;

void setnonblocking(int sock)
{
    int opts;
    opts = fcntl(sock, F_GETFL);
    if(opts < 0)
    {
        perror("fcntl(sock, GETFL)");
        exit(1);
    }
    opts = opts | O_NONBLOCK;
    if(fcntl(sock, F_SETFL, opts) < 0)
    {
        perror("fcntl(sock, SETFL, opts)");
        exit(1);
    }
}

int main()
{
    int i, maxi, listenfd, connfd, sockfd, nfds;
    pthread_t tid1, tid2;
    struct task *new_task = NULL;
    struct user_data *rdata = NULL;
    socklen_t clilen;

    pthread_mutex_init(&mutex, NULL);           //初始化互斥锁
    pthread_cond_init(&condl, NULL);            //初始化条件变量

    pthread_create(&tid1, NULL, readtask, NULL);
    pthread_create(&tid2, NULL, readtask, NULL);

    epfd = epoll_create(256);
    struct sockaddr_in clientaddr;
    struct sockaddr_in serveraddr;

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    setnonblocking(listenfd);                   //把socket设置为非阻塞方式
    ev.data.fd = listenfd;                      //设置与要处理的事件相关的文件描述符
    ev.events = EPOLLIN | EPOLLET;              //设置要处理的事件类型

    epoll_ctl(epfd, EPOLL_CTL_ADD, listenfd, &ev);
    bzero(&serveraddr, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    //inet_aton(local_addr, &(serveraddr.sin_addr));
    serveraddr.sin_port = htons(8090);

    bind(listenfd, (struct sockaddr*)&serveraddr, sizeof(serveraddr));
    listen(listenfd, 20);
    maxi = 0;

    for(;;)
    {
        printf("begin...\n");
        nfds = epoll_wait(epfd, events, 20, 500);       //等待最多20个，超时500ms

        for(i = 0; i < nfds; i++)
        {
            if(events[i].data.fd == listenfd)
            {
                connfd = accept(listenfd, (struct sockaddr*)&clientaddr, &clilen);
                if(connfd < 0)
                {
                    perror("connfd < 0");
                    exit(1);
                }
                setnonblocking(connfd);
                char *str = inet_ntoa(clientaddr.sin_addr);
                printf("connec_from %s", str);
                ev.data.fd = connfd;

                ev.events = EPOLLIN|EPOLLET;        //注册事件
                epoll_ctl(epfd, EPOLL_CTL_ADD, connfd, &ev);
            }

            else if(events[i].events&EPOLLIN)
            {
                printf("reading !\n");
                if((sockfd = events[i].data.fd) < 0)
                    continue;
                struct task *new_task;
                new_task->fd = sockfd;
                new_task->next = NULL;
                pthread_mutex_lock(&mutex);
                if(readhead == NULL)
                {
                    readhead = new_task;
                    readtail = new_task;
                }
                else
                {
                    readtail->next = new_task;  //?
                    readtail = new_task;
                }

                pthread_cond_broadcast(&condl);
                pthread_mutex_unlock(&mutex);
            }
            else if(events[i].events&EPOLLOUT)
            {
                rdata = (struct user_data*)events[i].data.ptr;
                sockfd = rdata->fd;
                write(sockfd, rdata->line, rdata->n_size);

                free(rdata);
                rdata = NULL;
                ev.data.fd = sockfd;

                ev.events = EPOLLIN|EPOLLET;
                epoll_ctl(epfd, EPOLL_CTL_MOD, sockfd, &ev);
            }
        }
    }
}


void *readtask(void *args)
{
    int fd = -1;
    unsigned int n;

    struct user_data *data = NULL;      //用于把读出来的数据传递出去

    while(1)
    {
        pthread_mutex_lock(&mutex);     //上锁

        while(readhead == NULL)         //等到任务队列不为空
        {
            pthread_cond_wait(&condl, &mutex);  //条件变量
        }
        fd = readhead->fd;

        struct task*tmp = readhead;
        free(tmp);
        tmp = NULL;

        pthread_mutex_unlock(&mutex);

        data->fd = fd;

        if((n = read(fd, data->line, MAXLINE)) < 0)
        {
            if(errno == ECONNRESET)
            {
                close(fd);

            }
            else
            printf("readline error\n");
            if(data != NULL)
                free(data);

        }
        else if(n == 0)
        {
            close(fd);
            printf("client close connect\n");
            if(data != NULL)
                free(data);
        }
        else
        {
            data->n_size = n;
            ev.data.ptr = data;             //设置需要传递出去的数据
            ev.events = EPOLLOUT|EPOLLET;   //设置用于注册的写操作事件
            epoll_ctl(epfd, EPOLL_CTL_MOD, fd, &ev);    //修改sockfd上要处理的事件为EPOLLOUT
        }
    }
}


