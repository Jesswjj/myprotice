#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <linux/tcp.h>
#include <linux/if_ether.h>
#include <linux/udp.h>
#include <net/if.h>

int main()
{
    int fd;
    fd = socket(AF_INET, SOCK_PACKET, htons(0x0003));

    char *ethname = "eth0";
    struct ifreq ifr;
    strcpy(ifr.ifrn_name, ethname);
    i = ioctl(fd, SIOCGIFFLAGS, &ifr);
    if(i<0)
    {
        close(fd);
        perror("can't get flags \n");
        return -1;
    }
    ifr.ifr_flags != IFF_PROMISC;
    i = ioctl(fd, SIOCSIFFLAGS, &ifr);
    if(i < 0)
    {
        perror("promiscuous set error\n");
        return -2;
    }
}
