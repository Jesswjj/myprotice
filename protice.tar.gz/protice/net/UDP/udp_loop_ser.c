#include <stdio.h>
#include <sys/types.h>
#include <linux/socket.h>
#include <sys/socket.h>
#include <netinet/in.h>
//循环UDP服务器设计流程

int main()
{
    int serfd;
    char buf[20] = "";
    struct sockaddr_in seraddr, cliaddr;
    socklen_t len;
    serfd = socket(AF_INET, SOCK_DGRAM, 0);      //步骤1：建立socket套接字

    bzero((void *)&seraddr, sizeof(struct sockaddr_in));
    seraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    seraddr.sin_family = AF_INET;
    seraddr.sin_port = htons(9999);

    bind(serfd, (struct sockaddr*)&seraddr, sizeof(seraddr));   //步骤2：绑定本地地址

    while(1)            //步骤3：开始循环
    {
        bzero(buf, 20);
        len = sizeof(struct sockaddr);
        recvfrom(serfd, buf, 20, 0, (struct sockaddr*)&cliaddr, &len);
        printf("%s", buf);
        sendto(serfd, buf, 20, 0, (struct sockaddr*)&cliaddr, &len);
    }
}
