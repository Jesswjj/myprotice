#include <stdio.h>
#include <sys/socket.h>
#include <linux/ip.h>
#include <linux/if.h>
#include <linux/udp.h>
#include <linux/tcp.h>
#include <sys/ioctl.h>

struct arppacket
{
    unsigned short ar_hrd;
    unsigned short ar_pro;
    unsigned short ar_hln;
    unsigned short ar_pln;
    unsigned short ar_op;
    unsigned char ar_sha[ETH_ALEN];
    unsigned char ar_sip[4];
    unsigned char ar_tha[ETH_ALEN];
    unsigned char ar_tip[4];
};

int main(int argc, char *argv)
{
    char ef[ETH_FRAME_LEN];
    struct ethhdr *p_ethhdr;
    char eth_dest[ETH_ALEN]={0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};/*源地址*/
    char eth_source[ETH_ALEN]={0x00, 0x0c, 0x29, 0x3a, 0x0c, 0x0c};
    char eth_dest[4] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    int n;
    int fd;
    fd = socket(AF_INET,  SOCK_PACKET, htons(0x0003));

    p_ethhdr = (struct ethhdr*)ef;
    memcpy(p_ethhdr->h_dest, eth_dest, ETH_ALEN);
    memcpy(p_ethhdr->h_source, eth_source, ETH_ALEN);

    p_ethhdr->h_proto = htons(0x0806);

    struct appacket *p_arp;
    p_arp = ef + ETH
}
