#include <stdio.h>
#include <stdlib.h>

#define IP_FOUND "IP_FOUND"
#define IP_FOUND_ACK "IP_FOUND_ACK"

void handle_ipfound(void *arg)
{
#define BUFFER_LEN 32
    int ret = -1;
    SOCKET sock = -1;

    struct sockaddr_in local_addr;
    struct sockaddr_in from_addr;

    int from_len;
    int count = -1;
    fd_set readfd;
    char buff[BUFFER_LEN];
    struct timeval timeout;
    timeout.tv_sec = 2;
    timeout.tv_usec = 0;

    DBGPRINT("==>HandleIpFound\n")
}
