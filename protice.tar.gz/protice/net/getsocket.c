#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/if_arp.h>
#include <sys/ioctl.h>
#include <string.h>
#include <linux/sockios.h>
#include <linux/if.h>
#include <stdlib.h>

int main()
{
    int s;
    int err = -1;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if(s < 0)
    {
        perror("socket");
        return -1;
    }
    //获得网络接口的名称
    struct ifreq ifr;
    ifr.ifr_ifindex = 2;//获取第2个网络接口的名称
    err = ioctl(s, SIOCGIFNAME, &ifr);
    if(err)
    {
        printf("SIOCGIFNAME Error\n");
    }
    else
    {
        printf("the %d est interface is:%s\n", ifr.ifr_ifindex, ifr.ifr_name);
    }
#if 0
    err = ioctl(s, SIOGIFMETRIC, &ifr);
    if(!err)
    {
        printf("SIOCGIFMETRIC:%d\n", ifr.ifr_metric);
    }

    err = ioctl(s, SIOGIFMTU, &ifr);
    if(!err)
    {
        printf("SIOCGIFMTU:%d\n", ifr.ifr_mtu);
    }
#endif
    err = ioctl(s, SIOCGIFHWADDR, &ifr);
    if(!err)
    {
        unsigned char *hw = ifr.ifr_hwaddr.sa_data;
        printf("SIOCGIFHWADDR:%02x:%02x:%02x:%02x:%02x:%02x\n", hw[0], hw[1], hw[2], hw[3], hw[4], hw[5]);
    }

}
