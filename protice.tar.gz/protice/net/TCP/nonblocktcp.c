#include <stdio.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <unistd.h>
#include <
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define PORT 9999
#define BACKLOG 4


int main(int argc, char *argv[])
{
    struct sockaddr_in local, client;
    int len;
    int s_s = -1, s_c = -1;

    local.sin_family = AF_INET;
    local.sin_port = htons(PORT);
    local.sin_addr = htonl(-1);

    s_s = socket(AF_INET, SOCK_STREAM, 0);

    fcntl(s_s, F_SETFL, O_NONBLOCK);

    listen(s_s, BACKLOG);
    for(;;)
    {
        while(s_c < 0)
            s_c = accept(s_s, (struct sockaddr*)&client, &len);

        while(recv(s_c, buffer, 1024) <= 0)
            ;
        if(strcmp(buffer, "HELLO") == 0)
        {
            send(s, "OK", 3, 0);
            close(s_c);
            continue;
        }
        if(strcmp(buffer, "SHUTDOWN") == 0)
        {
            send(s, "BYE", 3, 0);
            close(s_c);
            break;
        }

    }
    close(s_s);
    return 0;
}
