#include <net/ethernet.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>

void set_keepalive(int sockfd)
{
    int keepAlive=1;
    int keepIdle=20;
    int keepInterval=20;
    int keepCount=3;
    //printf("set_keepalive\n");
    unsigned int timeout=10000;//10s
    setsockopt(sockfd,IPPROTO_TCP,TCP_USER_TIMEOUT,&timeout,sizeof(timeout));

    if(setsockopt(sockfd,SOL_SOCKET,SO_KEEPALIVE,(void *)&keepAlive,sizeof(keepAlive))!=0)
    {
        printf("SO_KEEPALIVE WRONG!");
        //exit(1);
    }
    if(setsockopt(sockfd,SOL_TCP,TCP_KEEPIDLE,(void *)&keepIdle,sizeof(keepIdle))!=0)
    {
        printf("TCP_KEEPIDLE WRONG!");
        //exit(1);
    }
    if(setsockopt(sockfd,SOL_TCP,TCP_KEEPINTVL,(void *)&keepInterval,sizeof(keepInterval))!=0)
    {
        printf("TCP_KEEPIDLE WRONG!");
        //exit(1);
    }
    if(setsockopt(sockfd,SOL_TCP,TCP_KEEPCNT,(void *)&keepCount,sizeof(keepCount))!=0)
    {
        printf("TCP_KEEPCNT WRONG!");
        //exit(1);
    }
}

int main()
{



}
