/********************************************************************
*Module Name:         //模块的名字
*Module Date:9/8/2016 //生成日期
*Module Auth:jess     //作者名字
*Description:
*                // 用于详细说明此程序文件完成的主要功能，与其他模块
*                // 或函数的接口，输出值、取值范围、含义及参数间的控
*                // 制、顺序、独立或依赖等关系
*Others:         // 其它内容的说明所进行的修改
*Revision History:
*Date Rel Ver. Notes
*月/日/年 x.x
********************************************************************/
/*----------------Includes---------------*/
//包含的头文件
/*------------Local Variables----------- */
//定义一些本地变量
/*------Local Structures and Typedefs ---*/
//要使用的一些数据结构
/*-----------Extern Variables -----------*/
//使用到的一些外部变量
/*-------------Definitions---------------*/
//一些#defines及具体的函数实现
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <net/ethernet.h>



int main(int argc, char *argv[])
{
    unsigned short port = 8080;
    char cli_ip[INET_ADDRSTRLEN] = {0};

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    int connfd;

    if(sockfd < 0)
    {
        perror("socket");
        exit(1);
    }

    struct sockaddr_in my_addr, client_addr;
    socklen_t cliaddr_len = sizeof(client_addr);
    bzero(&my_addr, sizeof(my_addr));
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(port);
    my_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    int err_log = bind(sockfd, (struct sockaddr*)&my_addr, sizeof(my_addr));
    if(err_log != 0)
    {
        perror("binding");
        close(sockfd);
        exit(1);
    }



    err_log = listen(sockfd, 10);
    if(err_log != 0)
    {
        perror("listen");
        close(sockfd);
        exit(1);
    }
    printf("listening...\n");

    while(1)
    {
        connfd = accept(sockfd, (struct sockaddr*)&client_addr, &cliaddr_len);
        if(connfd < 0)
        {
            perror("accept");
            close(sockfd);
            exit(1);
        }
        pid_t pid = fork();
        if(pid < 0)
        {
            perror("fork");
            exit(1);
        }
        else if( 0 == pid)
        {
            close(sockfd);
            char recv_buf[1024] = {0};
            int recv_len = 0;

            memset(cli_ip, 0, sizeof(cli_ip));
            inet_ntop(AF_INET, &client_addr.sin_addr, cli_ip, INET_ADDRSTRLEN);
            printf("--------------------------------------\n");
            printf("client ip = %s, port = %d\n", cli_ip, ntohs(client_addr.sin_port));

            while((recv_len = recv(connfd, recv_buf, sizeof(recv_buf), 0)) > 0)
            {
                printf("recv_buf:%s\n", recv_buf);
                send(connfd, "i have rcv", 11, 0);
            }

            printf("client closed!\n");
            close(connfd);
            exit(0);
        }
        else if(pid > 0)
        {
            close(connfd);
        }
    }
    close(sockfd);
    return 0;
}
