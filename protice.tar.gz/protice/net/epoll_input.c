#include <sys/epoll.h>
#include <fcntl.h>

#define MAX_BUF 1000
#define MAX_EVEVTS 5

int main(int argc, char* argv[])
{
    int epfd, ready, fd, s, j, numOpenfds;
    struct epoll_event ev;
    struct epoll_event evlist[MAX_EVEVTS];

    char buf[MAX_BUF];

    if(argc < 2 || strcmp(argv[1], "--help") == 0)
        printf("$s file... \n", argv[0]);

    epfd = epoll_create(argc -1);//1
    if(epfd == -1)
        perror("epoll_create");

    for(j = 1; j < argc; j++)//2
    {
        fd = open(argv[j], O_RDONLY);
        if(fd == -1)
            perror("open");
        printf("open \"%s\" on fd %d\n", argv[j], fd);

        ev.events = EPOLLIN;
        ev.data.fd = fd;
        if(epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) == -1)//3
            perror("epoll_ctl");
    }

    while(numOpenfds > 0)
    {
        printf("About to epoll_wait\n");
        ready = epoll_wait(epfd, &evlist, )
    }

}
