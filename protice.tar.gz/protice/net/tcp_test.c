#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>

int main()
{
    int sock_fd, cli_fd;
    int res, i;
    struct sockaddr_in serv_addr, cli_addr;
    char send_buf = "tcp test:";

    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(8090);
    serv_addr.sin_addr.s_addr = inet_addr("192.168.2.110");
    //printf("%s", (char*)serv_addr.sin_addr.s_addr);
    sock_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(sock_fd < 0)
    {
        perror("socket");
        exit(1);
    }

    res = bind(sock_fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
    if(res < 0)
    {
        perror("bind");
        exit(1);
    }

    res = listen(sock_fd, 20);
    if(res < 0)
    {
        perror("listen");
        exit(1);
    }
    printf("listening...\n");
    socklen_t len = sizeof(struct sockaddr_in);
    cli_fd = accept(sock_fd, (struct sockaddr*)&cli_addr, &len);

    if(cli_fd < 0)
    {
        perror("accept");
        exit(1);
    }
    else
    while(1)
    {
        i = 0;
        strcat(send_buf, (char*)i);
        if(send(cli_fd, send_buf, sizeof(send_buf), 0) < 0);
        {
            perror("send");
            exit(1);
        }
        sleep(1);
        i++;
    }

    close(sock_fd);
    close(cli_fd);

    return 0;
}
