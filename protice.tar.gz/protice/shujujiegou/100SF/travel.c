#include <stdio.h>


int board[8][8] = {0};
int travel(int x, int y)
{
    int ktmove1[8] = {-2, -1, 1, 2, 2, 1, -1, -2};
    int ktmove2[8] = {1, 2, 2, 1, -1, -2, -2, -1};

    int nexti[8] = {0};
    int nextj[8] = {0};

    int exists[8] = {0};
    int i, j, k, m, l;
    int tmpi, tmpj;
    int count, min, tmp;

    i = x;
    j = y;
    board[i][j];

    for(m=2;m<=64;m++)
    {
        for(l=0; l < 8; l++)
            exists[1] = 0;

            l=0
    }

}
int main()
{
    int startx, starty;
    int i, j;
    printf("输入起点：");
    scanf("%d%d", &startx, &starty);

    if(travel(startx, starty))
    {
        printf("完成！\n");
    }
    else
    {
        printf("失败！\n");
    }

    for(i=0; i<8; i++)
    {
        for(j=0;j<8;j++)
            printf("%2d", board[i][j]);
        putchar("\n");
    }
    return 0;
}
