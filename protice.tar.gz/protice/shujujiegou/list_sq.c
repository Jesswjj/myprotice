#include <stdio.h>
#include <stdlib.h>
//-------线性表的动态 分配顺序存储结构
#define LIST_INIT_SIZE  100
#define LISTINCREMENT 10
struct sqlist
{

}
