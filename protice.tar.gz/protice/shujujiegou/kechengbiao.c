#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int year, month, day;
    int hour, minute, second;
}DATE;

typedef struct
{
    DATE date;
    char name[20];      //课程名称
    char address[20];   //上课地点
}Lesson;

void AddLesson(Lesson less, int tableID);

void UpdateLesson(Lesson less, int tableID);

void DeleteLesson(Lesson less, int tableID);

int AddNewTable();
void DeleteTable();

bool NewFile(char *filename);
bool DelFile(char *filename);

void SetDayRemind(int day, int min);
void SetDefaultUser();
void SetFirstWeek();

void Login();
void ShowMenu();
void ShowToday();

bool ReadTable(char *user);
void ShowMessage();
bool checkAlarm();

void CreateAlarm();
void DelAlarm();

void NewUser(char *name);
void UpdateUser(char *name);
void DelUser(char *name);


bool ReadTable(char *user)
{
    //负责把字符串按照课程和周次处理
    lessonIndex = 0;
    weekIndex = 0;

    //读入课程表信息
    FILE *file = NULL;

    file = fopen("data.txt", "rb");
    if(file == NULL)
    {
        return true;
    }

    char inf[80];

}
