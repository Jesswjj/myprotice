#include "seqlist.h"

void SeqListInit(SeqListType* SL)
{
    SL->ListLen=0;
}

int SeqListLength(SeqListType* SL)
{
    return (SL->ListLen);
}

int SeqListAdd(SeqListType *SL, DATA data)              //向顺序表中添加元素
{
    if(SL->ListLen >= MAXSIZE)
    {
        printf("顺序表已满，不能再添加结点了。\n");
        return 0;
    }
    SL->ListData[++SL->ListLen] = data;
    return 1;
}

int SeqListInsert(SeqListType *SL, int n, DATA data)    //向顺序表中插入元素
{
    int i;
    if(SL->ListLen >= MAXSIZE)                          //顺序表结点数量已超过最大数量
    {
        printf("顺序表已满，不能插入结点。\n");
        return 0;
    }
    if(n < 1||n > SL->ListLen-1)
    {
        printf("插入结点序号错误，不能插入元素！\n");
        return 0;
    }
    for(i=SL->ListLen;i>=n;i--)
        SL->ListData[i+1] = SL->ListData[i];
    SL->ListData[n]=data;
    SL->ListLen++;
    return 1;
}
int SeqListDelete(SeqListType *SL, int n)               //删除顺序表中的数据元素
{
    int i;
    if(n<1||n>SL->ListLen+1)
    {
        printf("删除结点序号错误，不能删除结点！\n");
        return 0;
    }
    for(i=n;i<SL->ListLen;i++)
        SL->ListData[i]=SL->ListData[i+1];
    SL->ListLen--;
    return 1;

}
DATA *SeqListFindByNum(SeqListType *SL, int n)          //根据序号返回元素
{
    if(n < 1 || n > SL->ListLen+1)
    {
        printf("结点序号错误，不能返回结点！\n");
        return NULL;
    }
    return &(SL->ListData[n]);
}


int SeqListFindByCont(SeqListType *SL, char *key)       //按关键字查找
{
    int i;
    for(i=1;i<=SL->ListLen;i++)
        if(strcmp(SL->ListData[i].key, key) == 0)
            return i;
    return 0;
}

int SeqListAll(SeqListType *SL)                         //遍历顺序表中的内容
{
    int i;
    for(i=1;i<=SL->ListLen;i++)
    {
        printf("(%s %s, %d)\n", SL->ListData[i].key, SL->ListData[i].name, SL->ListData[i].age);
    }
}

