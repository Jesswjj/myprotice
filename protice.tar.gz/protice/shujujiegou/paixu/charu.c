//插入排序


#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define MAXSIZE 20
typedef int KeyType;
typedef struct
{
    KeyType key;
    int otherinfo;
}RedType;

typedef struct
{
    RedType r[MAXSIZE];
    int length;
}Sqlist;


void Insertsort(sqlist *L);
{
    if(LT(L.r[i].key, L.r[i-1].key))
    {
        L.r[0] = L.r[i];
        L.r[i] = L.r[i-1];
        for(j = i-2; LT(L.r[0].key); --j)
            L.r[j+1] = L.r[j];
        L.r[j+1] = L.r[0];
    }
}

//折半插入排序
void Binsertsort(Sqlist *L)
{
    for(i= 2; i<=L.length; ++i)
    {
        L.r[0] = L.r[i];
        low = 1; high = i-1;
        while(low <= high)
        {
            ;
        }
    }
}

void Inputdata(int list[], int n)
{
    printf("input data:\n");
    for(int i=0; i < n; i++)
    {
        scanf("%d", &list[i]);
    }
}

void outputdata(int list[], int n)
{
    printf("\nthe current soring is:");
    for(int k=0; k<n; k++)
        printf("%d", list[k]);
}

void insertsort(int list[], int n)
{
    int i, j;
    int temp;
    for(i=0; i<n; i++)
    {
        temp = list[i];     //temp是监视哨
        j = i-1;
        while(temp < list[j])
        {
            list[j+1] = list[j];    //进行元素移动，以便腾出一个位置插入list[i]
            j--;
        }
        list[j+1] = temp;
        outputdata(list, n);
    }
}
