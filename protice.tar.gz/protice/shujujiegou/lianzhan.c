#include <stdio.h>
#include <stdlib.h>
#define stack_length 5
#define OK 1
#define ERROR 0

typedef int elemtype;

typedef struct Snode
{
    elemtype data;
    struct Snode *next;
}Snode, *Linkstack;
