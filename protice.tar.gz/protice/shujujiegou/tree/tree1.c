#include <stdio.h>
/*数组存储二叉树过程*/

#define MAX 30

/***------------------***/
//函数名：createtree(int btree[], int list[], int n)
//参数： int btree[] 二叉树
//      int list[]  数据类型
//      int n       数据数量
//功能： 建立二叉树

typedef struct
{
    int data;
    int left;
    int right;
}BtreeNode;

BtreeNode btree[MAX];

void createTree(btree *bt, int list, int n)
{
    int i;
    int level;
    int pos;        //左子树-1,右子树1

    bt[0].data = list[0];       //建立根结点
    for(i = 1; i < n; i++)
    {
        bt[i].data = list[i];   //元素存入结点
        level = 0;              //从根结点开始
        pos = 0;

        while(pos == 0)         //查找结点位置
        {

                if(bt[level].data < list[i])    //是否有下一层
                {
                    if(bt[level].right != -1)
                        level = bt[level].right;
                    else
                        pos = -1;               //设为右子树
                }
                else
                {
                    if(bt[level].left != -1)
                    {
                        level = bt[level].right;
                    }
                    else
                        pos = -1;    //设置为左子树
                }


        }
            //连接左右子树
            if(pos == 1)
                bt[level].left = i;
            else
                bt[level].right = i;
    }
}


void createtree(int *bt, int list[], int n)
{
    int i;
    int level;

    for(i = 0; i < MAX; i++)
    {
        bt[i] = 0;
    }

    bt[0] = list[0];        //建立二叉数根结点
    for(i = 1; i < n; i++)
    {
        level = 1;          //从第一层开始建立
        while(bt[level] != 0)       //判断是否有子树存在
        {
            if(list[i] < bt[level]) //建立左子树
                level = level * 2;
            else    level = level * 2 + 1;  //建立右子树
        }
        bt[level] = list[i];
    }
}

//测试主程序
void main()
{
    int count, i;
    int btree[MAX];
    int nodelist[MAX];

    printf("input the number of elements (n < 50):\n");
    scanf("%d", &count);
    printf("input elements:\n");
    for(i = 0; i < count; i++)
        scanf("%d", &nodelist, count);
    createtree(btree, nodelist, count);
    printf("the binary tree is:\n");
    for(i = 0; i < MAX; i++)
    {
        printf("%d", btree[i]);
    }
    printf("\n");
}
