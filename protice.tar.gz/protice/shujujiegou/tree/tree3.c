#include <stdio.h>
#include <stdlib.h>

#define MAX 50
//二叉树链表存储结构
typedef struct btnode
{
    int data;               //结点数据内容
    struct btnode *Llink;
    struct btnode *Rlink;
}btnode, *btreetype;

btreetype createTree(int n)
{
    int i;
    btreetype root = NULL;

    for(i = 0; i < n; i++)
    {
        btreetype newNode;
        btreetype currentNode;
        btreetype parentNode;

        newNode = (btreetype)malloc(sizeof(btnode));
        scanf("%d", &newNode->data);
        newNode->Llink = NULL;
        newNode->Rlink = NULL;

        curentNode = root;
        if(currentNode = NULL)
            root = newNOde;
        else
        {
            while(currentNode != NULL)
            {
                parentNode = currentNode;
                if(newNode->data < currentNode->data)
                    currentNode = currentNode->Link;
                    else
                    currentNode = currentNode->Rlink;
            }
            if(newNode->data < parentNode->data)
                parentNode->Llink = newNode;
            else
                parentNode->Rlink = newNode;
        }
    }
    return root;
}


int depth(btreetype &root)
{
    btreetype p;
    p = root;

    int dep1;
    int dep2;
    if(root == NULL)
        return 0;

    else
    {
        dep1 = depth(p->Llink);
        dep2 = depth(p->Rlink);

        if(dep1 > dep2)
            return (dep1 + 1);
        else return (dp2 + 1);
    }

}

void main()
{
    btreetype btree;
    int count;
    printf("input the number of elements:\n");
    scanf("%d", &count);
    printf("input data(num=%d):\n", count);
    btree = createTree(9);

}
