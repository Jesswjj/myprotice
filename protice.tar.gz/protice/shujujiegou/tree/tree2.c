#include <stdio.h>
#include <stdlib.h>
/*二叉树的链表存储实现*/
#define MAX 50

typedef struct btnode
{
    int data;                   //结点数据内容
    struct btnode *Llink;       //左子树
    struct btnode *Rlink;       //右子树
}btnode, *btreetype;
/**
createTree(int n)
参数：传入int n 数据数量
返回值：返回二叉树（根结点）指针
功能：建立二叉树
**/
btreetype createTree(int n)
{
    int i;
    btreetype root = NULL;

    for(i = 0; i < n; i++)
    {
        btreetype newNode;
        btreetype currentNode;
        btreetype parentNode;
        //建立新结点
        newNode = (btreetype)malloc(sizeof(btnode));
        scanf("%d", &newNode->data);
        newNode->Llink = NULL;
        newNode->Rlink = NULL;

        currentNode = root;         //存储当前结点指针
        if(currentNode == NULL)     //新结点作为二叉树根结点
            root = newNode;
        else
        {
            while(currentNode != NULL)
            {
                parentNode = currentNode;
                if(newNode->data <currentNode->data)        //比较结点数
                    currentNode = currentNode->Llink;       //左子树
                else
                    currentNode = currentNode->Rlink;       //右子树
            }
            //根据数值大小连接父结点和子结点
            if(newNode->data < parentNode->data)
                parentNode->Llink = newNode;
            else
                parentNode->Rlink = newNode;
        }
    }

    return root;
};

void outputtree(btreetype root)
{
    btreetype p;

    p = root->Llink;
    printf("建立的二叉树的左子树为：");
    while(p != NULL)
    {
        printf("%d ", p->data);
        p = p->Llink;
    }

    p = root->Rlink;
    printf("\n建立的二叉树的右子树为：");
    while(p!= NULL)
    {
        printf("%d ", p->data);
        p = p->Rlink;
    }
}

void main()
{
    btreetype btree;
    int count;
    printf("input the number of elemnts\n");
    scanf("%d", &count);

    printf("input data (num = %d):", count);
    btree = createTree(9);
    outputtree(btree);
}
