#include <stdio.h>
#include <stdlib.h>
//判断是否是排序二叉树
#define MAX 50
//二叉树链表存储结构
typedef struct btnode
{
    int data;       //结点数据内容
    struct btnode *Llink;//左子树指针
    struct btnode *Rlink;//右子树指针
}btnode, *btreetype;


btreetype createTree(int n)
{
    int i;
    btreetype root = NULL;

    for(i = 0; i < n; i++)
    {
        btreetype newNode;
        btreetype currentNode;
        btreetype parentNode;
        //建立新结点
        newNode = (btreetype)malloc(sizeof(btnode));
        scanf("%d", &newNode->data);
        newNode->Llink = NULL;
        newNode->Rlink = NULL;

        currentNode = root;         //存储当前结点指针
        if(currentNode == NULL)     //新结点作为二叉树根结点
            root = newNode;
        else
        {
            while(currentNode != NULL)
            {
                parentNode = currentNode;
                if(newNode->data <currentNode->data)        //比较结点数
                    currentNode = currentNode->Llink;       //左子树
                else
                    currentNode = currentNode->Rlink;       //右子树
            }
            //根据数值大小连接父结点和子结点
            if(newNode->data < parentNode->data)
                parentNode->Llink = newNode;
            else
                parentNode->Rlink = newNode;
        }
    }

    return root;
};

//**************//
//函数名：check(btreetype &root)
//参数：  btreetype root二叉树指针
//功能：判定一棵二叉树是否是二叉树
//*************//
int check(btreetype root)
{
    btreetype p;
    p = root;

    if(p == NULL)
        return 1;
    if(p->Llink && (p->Llink->data > p->data))
        return 0;
    if(p->Rlink && (p->Rlink->data < p->data))
        return 0;
    return(check(p->Llink) && check(p->Rlink));
}

void main()
{
    btreetype btree;
    int count;
    printf("input the number of elements:\n");
    scanf("%d", &count);
    printf("input data(num = %d):\n", count);
    btree = createTree(count);
    if(check(btree))
        printf("是二叉排序树\n");
    else
        printf("不是\n");
}
