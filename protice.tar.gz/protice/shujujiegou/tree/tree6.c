/*
哈夫曼编码程序的实现

*/
#define MAXVALUE 10000
#define MAXLEAF 30
#define MAXNODE 59
#define MAXBIT 10

#include <stdio.h>

typedef struct
{
    int data;       //结点值
    int weight;     //权重
    int flag;       //标识是否待构节点，是的话用0表示，否则用1表示
    int parent;     //父结点
    int Lchild;     //左结点
    int Rchild;     //右结点
}hnodetype;

typedef struct
{
    int bit[MAXBIT];
    int start;
}hcodetype;

//哈夫曼结点初始化
void inithaffman(hnodetype huffnode[], hcodetype huffcode[], int n)
{
    int i;

    for(i = 0; i < 2 * n - 1; i++)
    {
        huffnode[i].weight = 0;
        huffnode[i].parent = 0;
        huffnode[i].flag = 0;
        huffnode[i].Lchild = -1;
        huffnode[i].Rchild = -1;
    }

    for(i = 0; i < n; i++)
    {
        getchar();
        printf("输入第%d个叶结点值：", i+1);
        scanf("%c", &huffnode[i].data);
        printf("输入对应结点权值：");
        scanf("%d", &huffnode[i].weight);
    }
}

//输出哈夫曼编码
void outputhaffman(hnodetype huffnode[], hcodetype huffcode[], int n)
{
    int i, j;
    printf("%d个结点对应编码为：\n", n);
    for(i=0; i<n; i++)
    {
        printf("%c----", huffnode[i].data);
        for(j= huffcode[i].start + 1; j < n; j++)
            printf("%d", huffcode[i].bit[j]);
            printf("\n");

    }
}

//构造哈夫曼树，根据树生成哈夫曼编码
void haffman(hnodetype huffnode[], hcodetype huffcode[], int n)
{
    int i, j, m1, m2, x1, x2, c, p;
    hcodetype cd;

    for(i = 0; i < n-1; i++)    //构造哈夫曼树
    {
        //根据哈夫曼树的构成过程
        m1 = m2 = MAXVALUE;
        x1 = x2 = 0;
        for(j = 0; j < n+1; j++)
        {
            if(huffnode[j].weight < m1 && huffnode[j].flag == 0)
            {
                m2 = m1;
                x2 = x1;
                m1 = huffnode[j].weight;
                x1 = j;
            }
            else if(huffnode[j].weight < m2 && huffnode[j].flag == 0)
            {
                m2 = huffnode[j].weight;
                x2 = j;
            }
        }
        //把找到的两个节点按照哈夫曼树的规则构建成一个二叉树，x1为左孩子，x2为右孩子
        huffnode[x1].parent = n + i;
        huffnode[x2].parent = n + i;
        huffnode[x1].flag = 1;          //将x1的下标置1
        huffnode[x2].flag = 1;          //将x2的下标置1
        huffnode[n + i].weight = huffnode[x1].weight + huffnode[x2].weight;
        huffnode[n + i].Lchild = x1;
        huffnode[n + i].Rchild = x2;
    }

    for(i = 0; i < n; i++)      //根据哈夫曼树生成哈夫曼编码
    {
        cd.start = n - 1;
        c = i;
        p = huffnode[c].parent;

        while(p != 0)       //当父节点不为根节点的时候，逆序往上找
        {
            //如果当前是左孩子，则编码为0
            if(huffnode[p].Lchild == c)
                cd.bit[cd.start] = 0;
            else
                cd.bit[cd.start] = 1;
            cd.start--;
            c = p;
            p = huffnode;
        }
        for(j = cd.start + 1; j < n; j++)
        {
            huffcode[i].bit[j] = cd.bit[j];
            huffcode[i].start = cd.start;
        }
    }
}

void main()
{
    hnodetype huffnode[MAXNODE];
    hnodetype huffcode[MAXLEAF];
    int n;

    printf("输入叶结点个数n:\n");
    scanf("%d", &n);

    inithaffman(huffnode, huffcode, n);
    haffman(huffnode, huffcode, n);
    outputhaffman(huffnode, huffcode, n);
}
