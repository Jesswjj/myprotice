#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int num;
    long time;
} DATA;

#include "cycqueue.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#include "cycqueue.h"

int num;
void add(CycQueue *q)
{
    DATA data;

    if(!CycQueueIsFull(q))
    {
        data.num = ++num;
        data.time = time(NULL);
        CycQueueIn(q, data);
    }
    else
        printf("\n排队的人太多，请稍后再排队.\n");
}

void next(CycQueue *q)
{
    DATA *data;

    if(!CycQueueIsEmpty(q))
    {
        data = CycQueueOut(q);
        printf("\n请编号为%d的顾客办理业务！\n", data->num);
    }

    if(!CycQueueIsEmpty(q))
    {
        data = CycQueuePeek(q);
        printf("请编号为%d的顾客准备，马上将为您办理业务！\n", data->num);
    }
}
int main()
{
    CycQueue *queuel;

    char select;
    num = 0;
    queuel = CycQueueInit();

    if(queuel == NULL)
    {
        printf("创建队列时出错！\n");
        return 0;
    }

    do
    {
        printf("\n请选择具体操作：\n");
        printf("1.新到顾客\n");
        printf("2.下一个顾客\n");
        printf("0.退出\n");

        fflush(stdin);
        select = getc(stdin);

        switch(select)
        {
        case '1':
            add(queuel);
            printf("\n现在共有%d位顾客在等候！\n", CycQueueLen(queuel));
            break;

        case '2':
            next(queuel);
            printf("\n现在共有%d位顾客在等候！\n", CycQueueLen(queuel));
            break;

        case '0':
            break;
        }
    }
    while(select != '0');

    CycQueueFree(queuel);

    return 0;
}
