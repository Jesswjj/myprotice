#include <stdio.h>
#include <stdlib.h>


typedef struct
{
    char key[15];
    char addr[20];
    char telephone[15];
    char mobile[12];
}DATA;


void ChainListAll(ChainListType *head)
{
    ChainListType *h;
    DATA data;
    h = head;
    printf("链表所有数据如下：\n");

    while(h)
    {
        data = h->data;
        printf("姓名：%s\n", data.key);
        printf("地址：%s\n", data.addr);
        printf("电话：%s\n", data.telephone);
        printf("手机：%s\n", data.mobile);
        h = h->next;
    }
    return 0;
}
