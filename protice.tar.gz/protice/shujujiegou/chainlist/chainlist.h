#ifndef __CHAINLIST_
#define __CHAINLIST_


#include <stdlib.h>

typedef struct
{
    char key[15];
    char name[20];
    int age;
}DATA;


typedef struct Node
{
    DATA data;
    struct Node *next;
}ChainListType;

ChainListType *ChainListAddEnd(ChainListType *head, DATA data);

ChainListType *ChainListAddFirst(ChainListType *head, DATA data);

ChainListType *ChainListFind(ChainListType *head, char *key);

ChainListType *ChainListInsert(ChainListType *head, char *findkey, DATA data);

int ChainListDelete(ChainListType *head, char *key);

int ChainListLength(ChainListType *head);

void ChainListAll(ChainListType *head);
#endif
