#include <string.h>
#include "chainlist.h"
//添加结点到链表结尾
ChainListType *ChainListAddEnd(ChainListType* head, DATA data)
{
    ChainListType *node, *h;
    if(!(node = (ChainListType *)malloc(sizeof(ChainListType))))
    {
        printf("为保存结点数据申请内存失败！\n");
        return NULL;                            //分配内存失败
    }
    node->data = data;                          //保存数据
    node->next = NULL;                          //设置结点指针为空，即尾表尾
    if(head == NULL)                            //判断头指针是否为空
    {
        head = node;                            //链表头指针指向当前结点
        return head;                            //返回头指针
    }
    h = head;                                   //保存头指针

    while(h->next != NULL)                      //指向下一结点的地址不为NULL
        h = head->next;                         //指向下一个结点
    h->next = node;                             //最后结点指向新增结点
    return head;                                //返回头指针
}

//添加结点到首部
ChainListType *ChainListAddFirst(ChainListType* head, DATA data)
{
    ChainListType *node;
    if(!(node = (ChainListType *)malloc(sizeof(ChainListType))))
    {
        printf("为保存结点数据申请内存失败！\n");
        return NULL;                            //分配内存失败
    }
    node->data = data;                          //先保存数据

    node->next = head;                          //指向原来的头指针
    head = node;                                //头指针指向新增结点
    return head;
}
//插入结点
ChainListType *ChainListInsert(ChainListType* head, char* findkey, DATA data)
{
    ChainListType *node, *nodel;
    if(!(node = (ChainListType *)malloc(sizeof(ChainListType))))
    {
        printf("为保存结点数据申请内存失败！\n");
        return NULL;                            //分配内存失败
    }
    node->data = data;
    nodel = ChainListFind(head, findkey);
    if(nodel)
    {
        node->next = nodel->next;
        nodel->next = node;
    }
    else
    {
        free(node);
        node = NULL;            //free函数执行后，一定要接着设置指针为NULL。
        printf("未找到插入位置.\n");
    }

    return head;
}
//按关键字查找结点
ChainListType *ChainListFind(ChainListType* head, char* key)
{
    ChainListType *h;
    h=head;                                 //保存链表头指针
    while(h)                                //若结点有效，则进行查找
    {
        if(strcmp(h->data.key, key) == 0)   //若结点关键字与传入关键字相同
            return h;                       //返回该结点指针
        h = h->next;                        //处理下一结点
    }

    return NULL;                            //返回空指针

}

//删除结点
int ChainListDelete(ChainListType* head, char* key)
{
    ChainListType *h, *node;                        //node保存删除结点的前一结点
    h = head;
    node = h;
    while(h)
    {
        if(strcmp(h->data.key, key) == 0)           //找到关键字，执行删除操作
        {
            node->next = h->next;                   //使前一结点指向当前结点的下一结点
            free(h);                                //释放内容
            h = NULL;
            return 1;
        }
        else
        {
            node = h;                               //指向当前结点
            h = h->next;                            //指向下一结点
        }
    }

    return 0;                                       //未删除
}
//链表的长度
int ChainListLength(ChainListType* head)
{
    ChainListType *h;
    int i = 0;
    h = head;
    while(h)                                        //遍历整个链表
    {
        i++;                                        //累加结点数量
        h=h->next;                                  //处理下一结点
    }
    return i;                                       //返回结点数量
}

void ChainListAll(ChainListType *head)
{
    ChainListType *h;
    DATA data;
    h = head;
    printf("链表所有数据如下;\n");
    while(h)
    {
        data = h->data;
        printf("(%s, %s, %d)\n", data.key, data.name, data.age);
        h = h->next;

    }
    return ;
}
