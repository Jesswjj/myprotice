#include <stdio.h>
#include <stdlib.h>
#include "chainlist.h"

int main()
{
    ChainListType *node, *head = NULL;
    DATA data;
    char key[15], findkey[15];

    printf("请输入链表中的数据，包括关键字、姓名、年龄、关键字输入0，则退出：\n");
    do{
        fflush(stdin);
        scanf("%s", data.key);
        if(strcmp(data.key, "0") == 0)
            break;

        printf("请输入姓名和年龄：");
        scanf("%s%d", data.name, &data.age);
        head = ChainListAddEnd(head, data);
    }while(1);

    printf("该链表共有%d个结点。\n", ChainListLength(head));
    ChainListAll(head);


    printf("\n插入结点，输入位置的关键字：");
    scanf("%s", findkey);
    printf("请输入结点的数据(关键字 姓名 年龄):");
    scanf("%s%s%d", data.key, data.name, &data.age);
    head = ChainListInsert(head, findkey, data);

    ChainListAll(head);

    printf("\n在链表中查找，输入查找关键字：");
    fflush(stdin);
    scanf("%s", key);
    node = ChainListFind(head, key);
    if(node)
    {
        data = node->data;
        printf("关键子%s对应的结点数据为(%s,%s,%d)\n", key, data.key, data.name, data.age);

    }else
        printf("在链表中未找到关键字为%s的结点:\n", key);

    printf("\n在链表中删除结点，输入要删除的关键字：");

    fflush(stdin);
    scanf("%s", key);
    ChainListDelete(head, key);
    ChainListAll(head);

    return 0;

    return 0;
}
