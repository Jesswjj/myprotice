#include <iostream>
//使用指针数组
int main(int argc, char* argv[])
{
    short nShortMin = SHRT_MIN;
    int a[5] = {2, 3, 4, 5, 6};     //第一个数组
    int b[3] = {7, 8, 9};           //第二个数组
    int *pab[2];                    //定义一个指针数组
    //指针数组赋值，这里a可以左指针用
    pab[0] = a;
    pab[1] = b;
}
