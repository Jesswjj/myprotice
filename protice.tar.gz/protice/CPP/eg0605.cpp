#include <iostream>

using namespace std;

int main()
{
    int array1[3][3] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int array2[3][3] = {{3}, {6}, {9}};
    int array3[3][3] = {{1}, {0, 2}, {0, 0, 3}};
    int array4[ ][3] = {{3, 2, 1}, {6, 5, 4}, {9, 8, 7}};
    cout << "array1:" <<endl;
    for(size_t i = 0; i<3; i++)
    {
        for(size_t j=0; j<3; j++)
        {
            cout << array1[i][j] << " ";
        }
        cout << endl;
    }
    cout << "array2:" << endl;
    for(size_t i=0; i<3; i++)
    {
        for(size_t j=0; j<3; j++)
        {
            cout << array2[i][j] << " ";
        }
        cout << endl;
    }
    cout << "array3:" <<endl;
    for(size_t i=0; i<3; i++)
    {
        for(size_t j=0; j<3; j++)
        {
            cout << array3[i][j] << " ";
        }
        cout << endl;
    }
    cout << "array4:" <<endl;
    for(size_t i=0; i<3; i++)
    {
        for(size_t j=0; j<3; j++)
        {
            cout << array4[i][j] << " ";
        }
        cout << endl;
    }
    return 0;
}
