#include <iostream>
using namespace std;

int main()
{
    string str1;
    string str2("I LOVE CHINA");
    string str3(str2);
    string str4(5, '*');
    cout << "str1 value is:" << str1 << endl;
    cout << "str2 value is:" << str2 << endl;
    cout << "str3 value is:" << str3 << endl;
    cout << "str4 value is:" << str4 << endl;
    return 0;
}
