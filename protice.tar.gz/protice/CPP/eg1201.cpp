#include <iostream>

using namespace std;

class price
{
public:
    price()
    {
        unitprice = 0;
        number = 0;
        total = 0;
    }
    price(int u, int n)
    {
        unitprice = u;
        number = n;
        total = u * n;
    }
    void print()
    {
        cout << "price is :" << unitprice << endl;
        cout << "number is :" << number << endl;
        cout << "total is:" << total << endl;
    }
    bool operator == (const price &p)
    {
        if(this->unitprice == p.unitprice && this->number == p.number)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
private:
    int unitprice;
    int number;
    int total;
};

int main()
{
    price price1(1, 2);
    price price2(2, 1);
    price price3(1, 2);
    cout << "price1 is " ;
    price1.print();
    cout << "price1 is " ;
    price2.print();
    cout << "price1 is " ;
    price3.print();

    if(price1 == price2)
    {
        cout << "price1 == price2" << endl;
    }
    else
    {
        cout << "price1 != price2" << endl;
    }
}
