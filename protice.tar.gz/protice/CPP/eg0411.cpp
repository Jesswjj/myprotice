#include <iostream>
using namespace std;

int main()
{
    int hiswords, herwords;
    cout << "请输入他们说的话的真假：" << endl;
    cin >> hiswords >> herwords;
}
