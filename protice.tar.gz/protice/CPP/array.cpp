#include <iostream>

using namespace std;

int main()
{
    char a[3] = {'a'};
    int b[3] = {2};

    for(int i = 0; i < 3; i++)
    {
        cout << "char is:" << a[i] << endl;
        cout << "int is:" << b[i] << endl;
    }

}
