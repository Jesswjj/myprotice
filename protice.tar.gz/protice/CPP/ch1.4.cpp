#include <iostream>
#include <cmath>
using namespace std;
double max(double x, double y)
{
    if(x > y)
        return x;
    else
        return y;
}
int show();
int main(int argc, char* argv[])
{
    double a, b, c;
    cout << "input two numbers:" ;
    cin >> a >> b;
    show();
    max(a, b);
}

int show()
{
    cout << "the max num";
}
