#include <iostream>

using namespace std;

class watch
{
private:
    int hour;
    int minute;
    int second;
public:
    watch()
    {
        hour = 0;
        minute = 0;
        second = 0;
    }
    void change_hour(int n)
    {
        hour = n;
    }
    void change_minute(int n)
    {
        minute = n;
    }
    void change_second(int n)
    {
        second = n;
    }
    void settime(int h, int m, int s)
    {
        hour = h;
        minute = m;
        second = s;
    }
    void showtime()
    {
        cout << "time h:" << hour << endl;
        cout << "time m:" << minute << endl;
        cout << "time s:" << second << endl;
    }
};


int main()
{
    watch tm;
    tm.showtime();
    tm.change_hour(12);
    tm.change_minute(30);
    tm.change_second(25);
    tm.showtime();
    tm.settime(8, 30, 0);
    tm.showtime();

}
