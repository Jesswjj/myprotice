#include <iostream>

using namespace std;

int main()
{
    int a = 5;
    cout << &a << endl;
    return 0;
}
