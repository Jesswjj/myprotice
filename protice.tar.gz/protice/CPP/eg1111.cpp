#include <iostream>

using namespace std;

class printA
{
public:
    printA()
    {
        cout << "printA的构造函数被调用！" << endl;
    }
    ~printA()
    {
        cout << "printA的析构函数被调用！" << endl;
    }
};
class printB
{
public:
    printB()
    {
        cout << "printB的构造函数被调用！" << endl;
    }
    ~printB()
    {
        cout << "printB的析构函数被调用！" << endl;
    }
};
class printC
{
public:
    printC()
    {
        cout << "printC的构造函数被调用！" << endl;
    }
    ~printC()
    {
        cout << "printC的析构函数被调用！" << endl;
    }
};
int main()
{
    cout << "下面为析构函数与构造函数的执行过程" << endl;
    printA a;
    {
        printB b;
    }
    {
        printC c;
    }
    return 0;
}
