#include <iostream>

using namespace std;

class X
{
public:
    int first;
    int second;
    int third;
    void print();
};

void X::print()
{
    cout << "first value " << first << endl;
    cout << "second value " << second << endl;
    cout << "third value " << third << endl;
}


int main(int argc, char* argv[])
{
    X x;
    X *y = &x;
    x.first = 5;
    x.second = 6;
    x.third = 7;
    x.print();
    y->first = 8;
    y->second = 9;
    y->third = 10;
    y->print();
}
