#include <iostream>

using namespace std;
int add(int a)
{
    if(a>=1)
    {
        return add(a-1)+a;
    }
    return 0;
}
int main(int argc, char* argv[])
{
    int n;
    cout << "please input a num:";
    cin >> n;
    cout << "put out:" << add(n) << endl;
    return 0;
}
