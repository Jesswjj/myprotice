#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

double random(double start, double end)
{
    return start+(end-start)*rand()/(RAND_MAX + 1.0);
    //return rand() % (int)(start+end);
}



int main()
{
    srand(unsigned(time(0)));//设置随机发生数的种子
    int icnt;
    for(icnt = 0; icnt != 3; ++icnt)
        cout << "No." << icnt+1 << ":" << int(random(0, 50)) << endl;
    return 0;
}
