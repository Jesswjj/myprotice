#include <iostream>
#include <limits.h>
#include <stdio.h>
int main(int argc, char *argv[])
{
    short nShortMin = SHRT_MIN;             //最小有符号短整型
    short nShortMax = SHRT_MAX;
    unsigned short nUShortMax = USHRT_MAX;
    int nIntMin = INT_MIN;
    int nIntMax = INT_MAX;
    unsigned nUIntMax = UINT_MAX;
    long nLongMin = LONG_MIN;
    long nLongMax = LONG_MAX;
    unsigned long nULongMax = ULONG_MAX;
    printf("有符号短整型占用内存为%d, 其最大值和最小值分别是%d和%d;\n", sizeof(short), nShortMax, nShortMin);
    printf("无符号短整型占用内存为%d, 其最大值%d;\n", sizeof(unsigned short), nUShortMax);
    printf("有符号整型占用内存为%d, 其最大值和最小值分别是%d和%d;\n", sizeof(int), nIntMax, nIntMin);
    printf("无符号整型占用内存为%d, 其最大值为%u\n", sizeof(unsigned int), nUIntMax);
    printf("有符号长整型占用内存为%d, 其最大值和最小值为%ld和%ld:\n", sizeof(long), nLongMin, nLongMax);
    printf("无符号长整型占用内存为%d, 其最大值为%u\n", sizeof(unsigned long), nULongMax);

    return 0;

}
