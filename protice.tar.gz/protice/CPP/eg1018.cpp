#include <iostream>
#include <vector>

using namespace std;

int main(int argc, char* argv[])
{
    vector<int> vec(5);

    //定义了迭代器iter1指向vec的第一个元素
    vector<int>::iterator iter1 = vec.begin();
    //定义来迭代器iter2指向vec的最后一个元素超出末端的下一位置
    vector<int>::iterator iter2 = vec.end();
    if(iter1==iter2)
    {
        cout << "iter1 same to iter2" << endl;
    }
    else if(iter1 != iter2)
    {
        cout << "iter1 not same to iter2" << endl;
    }
}
