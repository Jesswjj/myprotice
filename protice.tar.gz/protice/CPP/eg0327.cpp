
#include <iostream>
using namespace std;

/*
什么是引用？
引用就是对象的另一个名字，相当于别名。
引用主要用作函数的形式参数，这只是它的主要用法。
*/


/*

-------------- 生成文件: "无目标" in "无项目" (compiler: 未知的)---------------

g++ -g  -c /home/jess/protice/CPP/eg0327.cpp -o /home/jess/protice/CPP/eg0327.o
/home/jess/protice/CPP/eg0327.cpp: In function ‘int main()’:
/home/jess/protice/CPP/eg0327.cpp:15:20: error: invalid initialization of non-const reference of type ‘double&’ from an rvalue of type ‘double’
     double &ref2 = val;         //错误
                    ^
/home/jess/protice/CPP/eg0327.cpp:16:10: error: ‘ref3’ declared as reference but not initialized
     int &ref3;                  //错误
          ^
/home/jess/protice/CPP/eg0327.cpp:17:17: error: invalid initialization of non-const reference of type ‘int&’ from an rvalue of type ‘int’
     int &ref4 = 2000;           //错误
                 ^
Process terminated with status 1 (0 minute(s), 0 second(s))
3 error(s), 0 warning(s) (0 minute(s), 0 second(s))


*/
int main()
{
    int val = 2008;
    int &ref1 = val;            //正确
    double &ref2 = val;         //错误        引用类型初始化错误
    int &ref3;                  //错误        没有初始化
    int &ref4 = 2000;           //错误        不能用常量来引用初始化
    int &ref5 = ref3;
    cout << "ref1" << endl;
}

/*
1.引用必须使用与该引用相同类型的对象进行初始化
2.引用必须进行初始化。
3.引用不能用文字常量来初始化。
4.不能定义引用类型的引用，也就是说引用不能用引用来初始化，但是存在其他类型的引用。
*/
