#include <iostream>

using namespace std;

int main()
{
    int year = 2008;
    int &ref = year;
    cout << "今年是" << ref << "年" <<endl;        //输出ref的值
    int &ref1 = year, &ref2 = year;
    ref1 += 1;
    cout << "1年后是" << ref1 << "年" << endl;
    cout << "year的值为：" << year << endl;
    ref2 += 1;
    cout << "2年后是" << ref2 << "年" << endl;
    cout << "year的值为：" << year << endl;
}
