#include <iostream>

using namespace std;

int main()
{
    int a = 5;
    int b = 10;
    int *const pa = &a;
    int const*pb = &b; //等价于const int *pb = &b

    cout << "a value is:" << a << endl;
    cout << "*pa value is:" << *pa <<endl;
    //pa = &b;    //不能改变指针的值
    *pb = 8;
}
