#include <iostream>
#include <vector>

using namespace std;

int main(int argc, char* argv[])
{
    int x;
    vector<int> vec;
    while(cin>>x)
    {
        vec.push_back(x);
    }

    for(vector<int>::size_type index = 0; index != vec.size(); index++)
    {
        cout << "vec have value:" << vec[index] << endl;
    }

}
