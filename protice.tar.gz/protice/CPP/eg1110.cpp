#include <iostream>
//拷贝构造函数

using namespace std;

class X                             //定义类X
{
public:
    X(int a, string str)                //构造函数完成数据成员的赋值
    {
        number = a;                     //给number进行赋值
        name = str;                     //给name进行赋值
    }
    X(const X &x):number(x.number), name(x.name){}  //拷贝构造函数的定义
    void print()
    {
        cout << "" << number << endl;   //输出number的值
        cout << "" << name << endl;     //输出name的值
    }
private:
    int number;
    string name;
};

int main()
{
    X x1(10, "tom");
    X x2(x1);
    x2.print();
    return 0;
}

