#include <iostream>

using namespace std;
class watch
{
friend void printtime(watch &wt);
public:
    watch()
    {
        hour = 0;
        minute = 0;
        second = 0;
    }
    void settime(int h, int m, int s)
    {
        hour = h;
        minute = m;
        second = s;
    }
private:
    int hour;
    int minute;
    int second;
};

void printtime(watch &wt)
{
    cout << "qi chuang shi jian :" << wt.hour << ":" << wt.minute << ":" << wt.second  << endl;
}

int main()
{
    watch tm;
    tm.settime(8, 30, 0);
    printtime(tm);


}
