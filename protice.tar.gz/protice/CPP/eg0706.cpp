#include <iostream>

using namespace std;

int main()
{
    string str;
    cout << "please input somes" << endl;
    while(getline(cin, str))
    {
        cout << "read str is:" << str << endl;
    }
}
