#include <iostream>

using namespace std;

int main()
{
    int val = 2008;
    int val2 = 2016;
    int &ref1 = val;     //定义引用 并初始化
     &ref1 = val2;
    std::cout << "今年是" << ref1 << "年" <<endl;
    ref1 += 10;
    std::cout << "十年后是" << ref1 << "年" << endl;
    cout << "val的值为：" << val << endl;
    //cout << "1 a的值为：" << a << endl;
    int a = ref1;
    cout << "2 a的值为：" << a << endl;

    return 0;
}
