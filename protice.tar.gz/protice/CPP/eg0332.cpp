#include <iostream>

using namespace std;

int main()
{
    int year = 2008;
    const int &ref1 = 2008;
    const int &ref2 = ref1 + year;
    const double &ref3 = year;
    cout << "ref1的值为：" << ref1 << endl;
    cout << "ref2的值为：" << ref2 << endl;
    cout << "ref3的值为：" << ref3 << endl;

    return 0;
}
