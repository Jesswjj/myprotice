#include <iostream>

using namespace std;

int main()
{
    string str = "tom";
    string *pstr = &str;
    string **pps = &pstr;
    cout << "str value is:" << str << endl;
    cout << "pstr value is:" << pstr << endl;
    cout << "pps value is:" << pps << endl;
    cout << "*pstr value is:" << *pstr << endl;
    cout << "*pps value is:" << *pps << endl;
    cout << "**pps value is:" << **pps << endl;
}
