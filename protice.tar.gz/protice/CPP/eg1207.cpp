#include <iostream>

using namespace std;

class price
{
public:
    price()
    {
        unitprice = 0;
        number = 0;
        total = 0;
    }
    price(int u, int n)
    {
        unitprice = u;
        number = n;
        total = u * n;
    }
    void print()
    {
        cout << "price is :" << unitprice << endl;
        cout << "number is :" << number << endl;
        cout << "total is:" << total << endl;
    }
    price& operator=(const price &p)
    {
        this->unitprice = p.unitprice;
        this->number = p.number;
        this->total = p.total;
    }

    bool operator == (const price &p)
    {
        if(this->unitprice == p.unitprice && this->number == p.number)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
private:
    int unitprice;
    int number;
    int total;
};

int main()
{
    price price1;
    price price2(1, 2);
    cout << "price1 is:" << endl;
    price1.print();
    cout << "price2 is:" << endl;
    price2.print();
    price1 = price2;
    cout << "price1 is:" << endl;
    price1.print();

}
