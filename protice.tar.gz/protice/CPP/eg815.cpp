#include <iostream>

using namespace std;

int main()
{
    const int a = 5;
    int b = 10;
    const int *p;       //不能用*p修改指向的值
    p = &a;

    cout << "*p value is:" << *p << endl;
    p = &b;
    cout << "*p value is:" << *p << endl;

    //*p = 1;
    cout << "*p value is:" << *p << endl;

}
