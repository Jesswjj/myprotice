#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>


/*
互斥锁基本操作
初始化和销毁互斥锁
在使用前先定义互斥锁（全局变量）
pthread_mutex_t lock;

初始化互斥锁函数
extern int pthread_mutex_init(pthread_mutex_t *__mutex, __const pthread_mutexattr_t *__mutexattr)
第一个参数mutex是指向要初始化的互斥锁的指针
第二个参数mutexattr是指向属性对象的指针，该属性对象定义要初始化的互斥锁的属性。如果该指针为NULL，则使用默认的属性。
此外，还可以使用宏PTHREAD——MUTEX——INITALIZER初始化静态分配的互斥锁，

lock = PTHRAED_MUTEX_INITALIZER


销毁互斥锁函数
extern int pthread_mutex_destroy (pthread_mutex_t *__mutex)


*/


void *thread_function(void *arg);
pthread_mutex_t work_mutex;

#define WORK_SIZE 1024
char work_area[WORK_SIZE];
int time_to_exit = 0;

int main(int argc, char *argv[])
{
    int res;
    pthread_t a_thread;
    void *thread_result;
    //初始化互斥锁
    res = pthread_mutex_init(&work_mutex, NULL);
    if(res != 0)
    {
        printf("Mutex initialization failed");
        exit(1);
    }
    //创建新线程
    res = pthread_create(&a_thread, NULL, thread_function, NULL);
    if(res != 0)
    {
        printf("Thread creation failed");
        exit(1);
    }
    //接收输入前，给互斥量上锁
    pthread_mutex_lock(&work_mutex);
    printf("Input some text. Enter 'end' to finish\n");
    while(!time_to_exit)//time_to_exit值由另一线程修改
    {
        fgets(work_area, WORK_SIZE, stdin);//从stdin读取到一行信息
        pthread_mutex_unlock(&work_mutex);//解锁，两个线程抢占互斥量
        while(1)
        {
            pthread_mutex_lock(&work_mutex);//上锁
            if(work_area[0] != '\0')//检查读入的内容输出没有
            {//输出线程将信息输出后将设置work_area[0] != '\0'
                pthread_mutex_unlock(&work_mutex);//如果没有输出，解锁
                sleep(1);
            }

            else//如果已经输出，执行下一轮读入
                break;
        }
    }
    //解锁
    pthread_mutex_unlock(&work_mutex);
    printf("\nWaiting for thread to finish..\n");//等待另一个线程结束
    res = pthread_join(a_thread, &thread_result);
    if(res != 0)
    {
        printf("Thread join failed");
        exit(1);
    }
    printf("Thread joined\n");
    pthread_mutex_destroy(&work_mutex);//销毁互斥锁
    exit(1);
}

void *thread_function(void *arg)//子线程执行的程序
{
    sleep(1);
    pthread_mutex_lock(&work_mutex);//上锁，抢占资源
    while(strncmp("end", work_area, 3) != 0)//判断是否为结束信息end
    {
        printf("You input %d characters\n", strlen(work_area) - 1);
        printf("the characters is %s", work_area);
        work_area[0] = '\0';
        pthread_mutex_unlock(&work_mutex);//解锁
        sleep(1);
        pthread_mutex_lock(&work_mutex);
        while(work_area[0] == '\0')
        {
            pthread_mutex_unlock(&work_mutex);
            sleep(1);
            pthread_mutex_lock(&work_mutex);
        }
    }

    time_to_exit = 1;
    work_area[0] = '\0';
    pthread_mutex_unlock(&work_mutex);
    pthread_exit(0);
}

