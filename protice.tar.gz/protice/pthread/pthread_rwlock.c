#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#define WORK_SIZE 1024
static pthread_rwlock_t rwlock;
char work_area[WORK_SIZE];
int time_to_exit;

void *thread_function_read_o(void *arg);
void *thread_function_read_t(void *arg);
void *thread_function_write_o(void *arg);
void *thread_function_write_t(void *arg);

int main(int argc, char *argv)
{
    int res;
    pthread_t a_thread, b_thread, c_thread, d_thread;
    void *thread_result;
    res = pthread_rwlock_init(&rwlock, NULL);
    if(res != 0)
    {
        perror("rwlock initialization failed");
        exit(1);
    }
    res = pthread_create(&a_thread, NULL, thread_function_read_o, NULL);
    if(res != 0)
    {
        perror("Thread_a creation failed");
        exit(1);
    }
    res = pthread_create(&b_thread, NULL, thread_function_read_t, NULL);
    if(res != 0)
    {
        perror("Thread_b creation failed");
        exit(1);
    }
    res = pthread_create(&c_thread, NULL, thread_function_write_o, NULL);
    if(res != 0)
    {
        perror("Thread creation failed");
        exit(1);
    }
    res = pthread_create(&d_thread, NULL, thread_function_write_t, NULL);
    if(res != 0)
    {
        perror("Thread creation failed");
        exit(1);
    }


    res = pthread_join(a_thread, &thread_result);
    if(res != 0)
    {
        perror("thread join failed");
        exit(1);
    }
    res = pthread_join(b_thread, &thread_result);
    if(res != 0)
    {
        perror("thread join failed");
        exit(1);
    }
    res = pthread_join(c_thread, &thread_result);
    if(res != 0)
    {
        perror("thread join failed");
        exit(1);
    }
    res = pthread_join(d_thread, &thread_result);
    if(res != 0)
    {
        perror("thread join failed");
        exit(1);
    }

    pthread_rwlock_destroy(&rwlock);
    exit(1);
}

void *thread_function_read_o(void *arg)
{
    printf("thread read one try to get lock\n");
    pthread_rwlock_rdlock(&rwlock);
    while(strncmp("end", work_area, 3) != 0)
    {
        printf("this is thread read one.");
        printf("the characters is %s\n", work_area);

        pthread_rwlock_unlock(&rwlock);     //解锁
        sleep(5);
        pthread_rwlock_rdlock(&rwlock);     //获取读取锁

        while(work_area[0] == '\0')
        {
            pthread_rwlock_unlock(&rwlock);
            sleep(5);
            pthread_rwlock_rdlock(&rwlock);
        }
    }

    pthread_rwlock_unlock(&rwlock);
    time_to_exit = 1;
    pthread_exit(0);
}

void *thread_function_read_t(void *arg)
{
    printf("thread read two try to get lock\n");
    pthread_rwlock_rdlock(&rwlock);
    while(strncmp("end", work_area, 3) != 0)
    {
        printf("this is thread read two.");
        printf("the characters is %s\n", work_area);

        pthread_rwlock_unlock(&rwlock);     //解锁
        sleep(5);
        pthread_rwlock_rdlock(&rwlock);     //获取读取锁

        while(work_area[0] == '\0')
        {
            pthread_rwlock_unlock(&rwlock);
            sleep(5);
            pthread_rwlock_rdlock(&rwlock);
        }
    }

    pthread_rwlock_unlock(&rwlock);
    time_to_exit = 1;
    pthread_exit(0);

}

void *thread_function_write_o(void *arg)
{
    printf("this is write thread one try to get lock\n");
    while(!time_to_exit)
    {
        pthread_rwlock_wrlock(&rwlock);
        printf("this is write thread one.\nInput some text.");
        printf("Enter 'end' to finish\n");
        fgets(work_area, WORK_SIZE, stdin);
        pthread_rwlock_unlock(&rwlock);
        sleep(15);
    }
    pthread_rwlock_unlock(&rwlock);
    pthread_exit(0);
}

void *thread_function_write_t(void *arg)
{
    sleep(10);
    while(!time_to_exit)
    {
        pthread_rwlock_wrlock(&rwlock);
        printf("this is write thread two.\nInput some text.");
        printf("Enter 'end' to finish\n");
        fgets(work_area, WORK_SIZE, stdin);
        pthread_rwlock_unlock(&rwlock);
        sleep(20);
    }
    pthread_rwlock_unlock(&rwlock);
    pthread_exit(0);
}
