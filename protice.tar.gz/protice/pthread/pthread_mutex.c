/*
两个线程：一个负责从标准输入设备中读取数据存储在全局数据区，另一个线程负责从标准输入设备中读取
数据存储在全局数据区，另一个线程负责将读入的数据输出到标准输出设备。
处理输入操作的线程在接收用户输入信息时不能被中断，因此要先使用互斥锁获得资源占用，阻塞其他线程的执行
输出线程中为了保证输出不被中断，同样在输入信息前后需要先锁定互斥锁，操作完成后释放互斥锁。
*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#define WORK_SIZE 1024

void *thread_function(void *arg);
pthread_mutex_t work_mutex;             //全局互斥锁

char work_area[WORK_SIZE];              //全局共享数据区
int time_to_exit = 0;

int main(int argc, char *argv[])
{
    int res;
    pthread_t a_thread;
    void *thread_reasult;

    res = pthread_mutex_init(&work_mutex, NULL);                 //初始化互斥锁
    if(res != 0)
    {
        printf("Mutex initialization failed");
        exit(1);
    }
    res = pthread_create(&a_thread, NULL, thread_function, NULL);//创建新线程
    if(res != 0)
    {
        printf("Thread creattion failed");
        exit(1);
    }
    pthread_mutex_lock(&work_mutex);    //接收输入前，给互斥锁上锁
    printf("Input some text, Enter 'end' to finish\n");
    while(!time_to_exit)                //time_to_exit值由另一线程修改
    {
        fgets(work_area, WORK_SIZE, stdin); //从stdin读取到一行信息
        pthread_mutex_unlock(&work_mutex);
        while(1)
        {
            pthread_mutex_lock(&work_mutex);
            if(work_area[0] != '\0')
            {   //输出线程将信息输出后将设置work_area[0] = '\0'
                pthread_mutex_unlock(&work_mutex);//如果没有输出，解锁
                sleep(1);
            }
            else                            //如果已经输出，执行下一轮读入
                break;
        }
    }
    pthread_mutex_unlock(&work_mutex);
    printf("\nWaiting for thread to finish..\n");
    res = pthread_join(a_thread, &thread_reasult);//等待另一个线程结束
    if(res != 0)
    {
        printf("Thread join failed");
        exit(1);
    }
    printf("Thread joined\n");
    pthread_mutex_destroy(&work_mutex); //销毁互斥锁
    exit(1);
}

void *thread_function(void *arg)        //子线程执行的程序
{
    sleep(1);
    pthread_mutex_lock(&work_mutex);            //上锁，抢占资源
    while(strncmp("end", work_area, 3) != 0)    //判断是否为结束信息end
    {
        printf("You input %d characters\n", strlen(work_area) - 1);
        printf("the characters is %s", work_area);
        work_area[0] = '\0';
        pthread_mutex_unlock(&work_mutex);
        sleep(1);
        pthread_mutex_lock(&work_mutex);
        while(work_area[0] == '\0')
        {
            //如果为'\0'，表示主线程还没有输入数据
            //如果不为'\0',则表示有输入，执行下一轮输入操作
            pthread_mutex_unlock(&work_mutex);
            sleep(1);
            pthread_mutex_lock(&work_mutex); //上锁，再次返回判断
        }
    }
    time_to_exit = 1;
    work_area[0] = '\0';
    pthread_mutex_unlock(&work_mutex);
    pthread_exit(0);
}
