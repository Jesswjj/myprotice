#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

typedef struct tpool_work
{
    void*   (*routine)(void*);      /* 任务函数 */
    void    *arg;                   /* 传入任务函数的参数 */
    struct tpool_work *next;
}tpool_work_t;

typedef struct tpool
{
    int shutdown;                    /* 线程池是否销毁 */
    int max_thr_num;                   /* 最大线程数 */
    pthread_t *queue_head;              /*线程ID数组*/
    tpool_work_t *queue_head;
    pthread_mutex_t queue_lock;
    pthread_cond_t  queue_ready;
}tpool_t;


int tpool_create(int max_thr_num);

void tpool_destroy();

int tpool_add_work(void*(*routine)(void*), void*arg);

static tpool_t *tpool = NULL;

static void* thread_routine(void *arg)
{
    tpool_work_t *work;

    while(1)
    {
        pthread_mutex_lock(&tpool->queue_lock);
        while(!tpool->queue_head && !tpool->shutdown)
        {
            pthread_cond_wait(&tpool->queue_ready, &tpool->queue_lock);
        }
        if(tpool->shutdown)
        {
            pthread_mutex_unlock(&tpool->queue_lock);
            pthread_exit(NULL);
        }
        work = tpool->queue_head;
        tpool->queue_head = tpool->queue_head->next;
        pthread_mutex_unlock(&tpool->queue_lock);

        work->routine(work->arg);
        free(work);
    }

    return NULL;
}


int tpool_create(int max_thr_num)
{
    int i;

    tpool = calloc(1, sizeof(tpool_t));
    if(!tpool)
    {
        printf("%s:calloc failed \n", __FUNCTION__);
        exit(1);
    }

    tpool->max_thr_num = max_thr_num;
    tpool->shutdown = 0;
    tpool->queue_head = NULL;
    if(pthread_mutex_init(&tpool->queue_lock, NULL) != 0)
    {
        printf("%s:pthread_mutex_init failed, errno:%d, error.%s\n", __FUNCTION__, error, strerror(errno));
        exit(1);
    }
    return 0;
}
/* 销毁线程池 */
void tpool_destroy()
{
    int i;
    tpool_work_t *member;

    if(tpool->shutdown)
    {
        return ;
    }
    tpool->shutdown = 1;
    /* 通知所有正在等待的线程 */
    pthread_mutex_lock(&tpool->queue_lock);
    pthread_cond_broadcast(&tpool->queue);
    pthread_mutex_unlock(&tpool->queue_lock);
    for(i = 0; i < tpool->max_thr_num, ++i)
    {
        pthread_join(tpool->thr_id[i], NULL);
    }
    free(tpool-thr_id);

    while(tpool->queue_head)
    {
        member = tpool->queue_head;
        tpool->queue_head = tpool->queue_head->next;
        free(member);
    }

    pthread_mutex_destroy(&tpool->queue_lock);
    pthread_cond_destroy(&tpool->queue_ready);

    free(tpool);
}

int tpool_add_work(void*(*routine)(void*), void *arg)
{
    tpool_work_t *work, *member;

    if(!routine)
    {
        printf("%s:Invalid argument\n", __FUNCTION__);
        return -1;
    }

    work = malloc(sizeof(tpool_work_t));
    if(!work)
    {
        printf("%s:malloc failed\n", __FUNCTION__);
        return -1;
    }
    work->routine = routine;
    work->arg = arg;
    work->next = NULL;

    pthread_mutex_lock(&tpool->queue_lock);
    member = tpool->queue_head;
    if(!member)
    {
        tpool->queue_head = work;
    }
    else
    {
        while(member->next)
        {
            member = member->next;
        }
        member->next = work;
    }

    pthread_cond_signal(&tpool->queue_ready);
    pthread_mutex_unlock(&tpool->queue_lock);

    return 0;
}


void *func(void *arg)
{
    printf("thread %d\n", (int)arg);
    return NULL;
}

int main(int arg, char **argv)
{
    if(tpool_create(5) != 0)
    {
        printf("tpool_create failed\n");
        exit(1);
    }

    int i;
    for(i = 0; i < 10; ++i)
    {
        tpool_add_work(func, (void*)i);
    }

    sleep(2);
    tpool_destroy();
    return 0;
}


