#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
//时间空间大小
#define BUFFER_SIZE 2
//条件信息结构体
struct prodcons
{
    int buffer[BUFFER_SIZE];    //生产产品值
    pthread_mutex_t lock;       //互斥锁
    int readpos, writepos;      //读写位置
    pthread_cond_t notempty;    //条件变量，表非空
    pthread_cond_t notfull;     //条件变量，表非满
};
//初始化
void init(struct prodcons *prod)
{
    pthread_mutex_init(&prod->lock, NULL);      //初始化互斥量
    pthread_cond_init(&prod->notempty, NULL);   //初始化条件变量
    pthread_cond_init(&prod->notfull, NULL);    //初始化条件变量
    prod->readpos = 0;                          //初始化读操作位置
    prod->writepos = 0;                         //初始化写操作位置
}

void put(struct prodcons *prod, int data)       //输入产品子函数
{
    pthread_mutex_lock(&prod->lock);            //锁定互斥锁
    //测试空间是否已满
    while((prod->writepos + 1) % BUFFER_SIZE == prod->readpos)
    {
        printf("producer wait for not full\n");
        pthread_cond_wait(&prod->notfull, &prod->lock);//等待有空间可写
    }
    prod->buffer[prod->writepos] = data;                //写数据
    prod->writepos++;                                   //写位置数加1
    if(prod->writepos >= BUFFER_SIZE)                   //如果写到尾部，返回
            prod->writepos = 0;
    pthread_cond_signal(&prod->notempty);               //发送有数据信号
    pthread_mutex_unlock(&prod->lock);                  //解锁
}

int get(struct prodcons *prod)                  //读取数据和
{
    int data;
    pthread_mutex_lock(&prod->lock);            //上锁
    while(prod->writepos == prod->readpos)      //测试是否有数据
    {
        printf("consumer wait for not empty\n");
        pthread_cond_wait(&prod->notempty, &prod->lock);//如果为空，等待
    }

    data = prod->buffer[prod->readpos];         //读数据
    prod->readpos++;                            //读指针加1
    if(prod->readpos >= BUFFER_SIZE)            //如果读到尾部，返回
        prod->readpos = 0;
    pthread_cond_signal(&prod->notfull);
    pthread_mutex_unlock(&prod->lock);

    return data;

}
#define OVER (-1)
struct prodcons buffer;
/*---------------------------------------------*/
void* producer(void *data)          //生产者
{
    int n;
    for(n = 1; n <= 5; n++)         //成产前5个产品
    {
        printf("producer sleep 1 second....\n");//每1秒生产一个产品
        sleep(1);
        printf("put the %d product\n", n);
        put(&buffer, n);
    }
    for(n = 6; n <= 10; n++)
    {
        printf("producer sleep 3 second....\n");//生产后5个产品
        sleep(3);
        printf("putt the %d product\n", n);     //每3秒生产一个产品
        put(&buffer, n);
    }

    put(&buffer, OVER);
    printf("producer stopped!\n");
    return NULL;
}
/*---------------------------------------------*/
void *consumer(void* data)              //消费者
{
    int d = 0;
    while(1)
    {
        printf("consumer sleep 2 second....\n");//每两秒消费一个产品
        sleep(2);
        d = get(&buffer);
        printf("get the %d product\n", d);
        if(d == OVER)
            break;
    }

    printf("consumer stopped!\n");
    return NULL;
}

int main()
{
    pthread_t th_a, th_b;
    void *retval;
    init(&buffer);
    pthread_create(&th_a, NULL, producer, 0);   //创建生产线程
    pthread_create(&th_b, NULL, consumer, 0);   //创建消费线程

    pthread_join(th_a, &retval);                //等待生产线程结束
    pthread_join(th_b, &retval);                //等待消费线程结束

    return 0;
}
