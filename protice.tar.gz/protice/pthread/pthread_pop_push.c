#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

void cleanup()//入栈的操作函数
{
    printf("cleanup\n");
}

void *test_cancel(void)
{   /*线程取消的时执行cleanup*/
    pthread_cleanup_push(cleanup, NULL);/*函数放栈*/
    printf("test_cancel\n");            /*打印提示信息*/
    while(1)
    {
        printf("test message\n");
        sleep(1);
    }
    pthread_cleanup_pop(1);/*出栈并执行*/
}

int main()
{
    pthread_t tid;
    pthread_create(&tid, NULL, (void *)test_cancel, NULL);/*创建线程*/
    sleep(2);
    pthread_cancel(tid);

    pthread_join(tid, NULL);//取消子线程
}


