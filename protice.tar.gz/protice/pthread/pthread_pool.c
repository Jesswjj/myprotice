#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <memory.h>
#include <sys/types.h>


typedef int bool;

#define false (0)
#define true (1)
/*线程任务链表*/
typedef struct _thread_worker_t
{
    void *(*process)(void *arg);    /*线程处理的任务*/
    void *arg;                      /*任务接口参数*/
    struct _thread_worker_t *next;  /*下一个结点*/
}thread_worker_t;

typedef struct
{
    pthread_mutex_t queue_lock;     /*队列互斥锁*/
    pthread_cond_t queue_ready;     /*队列条件锁*/

    thread_worker_t *head;          /*任务是队列头指针*/
    bool isdestroy;                 /*是否已销毁线程*/
    pthread_t *threadid;            /*线程ID数组，动态分配空间*/
    int reqnum;                     /*请求创建的线程个数*/
    int num;                        /*实际创建的线程个数*/
    int queue_size;                 /*工作队列当前大小*/
}thread_pool_t;



/*函数声明*/
int thread_pool_init(thread_pool_t **pool, int num);
int thread_pool_add_worker(thread_pool_t *pool, void *(*process)(void*arg), void *arg);
int thread_pool_keepalive(thread_pool_t *pool);
int thread_pool_destroy(thread_pool_t *pool);



/*************************************************************
 **功  能：线程池的初始化
 **参  数：
 **    pool：线程池对象
 **    num ：线程池中线程个数
 **返回值：0：成功 !0: 失败
 *************************************************************/
int thread_pool_init(thread_pool_t **pool, int num)
{
    int idx = 0;
    int ret;
    *pool = (thread_pool_t *)calloc(1, sizeof(thread_pool_t));
    if(NULL == *pool)
    {
        return -1;
    }

    pthread_mutex_init(&((*pool)->queue_lock), NULL);
    pthread_cond_init(&((*pool)->queue_ready), NULL);
    (*pool)->head = NULL;
    (*pool)->reqnum = num;
    (*pool)->queue_size = 0;
    (*pool)->isdestroy = false;
    (*pool)->threadid = (pthread_t*)calloc(1, num*sizeof(pthread_t));
    if(NULL == (*pool)->threadid)
    {
        free(*pool);
        (*pool) = NULL;

        return -1;
    }

    for(idx = 0; idx < num; idx++)
    {
        ret = thread_create_detach(*pool, idx);
        if(0 != ret)
        {
            return -1;
        }
        (*pool)->num++;
    }

    return 0;
}


/*************************************************************
 **功  能：将任务加入线程池处理队列
 **参  数：
 **    pool：线程池对象
 **    process：需处理的任务
 **    arg: process函数的参数
 **返回值：0：成功 !0: 失败
 *************************************************************/

 int thread_pool_add_worker(thread_pool_t *pool, void *(*process)(void *arg), void *arg)
 {
    thread_worker_t *worker = NULL, *member = NULL;

    worker = (thread_worker_t*)calloc(1, sizeof(thread_worker_t));
    if(worker == NULL)
    {
        return -1;
    }

    worker->process = process;
    worker->arg = arg;
    worker->next = NULL;

    pthread_mutex_lock(&(pool->queue_lock));

    member = pool->head;
    if(member != NULL)
    {
        while(NULL != member->next)
            member->next = worker;
    }
    else
    {
        pool->queue_size++;
    }

    pthread_mutex_unlock(&(pool->queue_lock));
    pthread_cond_signal(&(pool->queue_ready));

    return 0;
 }


 /******************************************************************************
 **函数名称: thread_pool_keepalive
 **功    能: 线程保活
 **输入参数:
 **       pool: 线程池
 **输出参数: NONE
 **返    回: 0: success !0: failed
 **实现过程:
 **      1. 判断线程是否存在
 **      2. 不存在，说明线程死亡，需重新创建
 ******************************************************************************/
 int thread_pool_keepalive(thread_pool_t *pool)
 {
    int idx = 0, ret = 0;

    for(idx = 0; idx < pool->num; idx++)
    {
        ret = pthread_kill(pool->thread[idx], 0);
        if(ESRCH == ret)
        {
            ret = thread_create_detch(pool, idx);
            if(ret < 0)
            {
                return -1;
            }
        }

    }
    return 0;
 }

 /*************************************************************
 **功  能：线程池的销毁
 **参  数：
 **    pool：线程池对象
 **返回值：0：成功 !0: 失败
 *************************************************************/
 int thread_pool_destroy(thread_pool_t *pool)
 {
    int idx = 0;
    thread_worker_t *member = NULL;

    if(false != pool->isdestroy)
    {
        return -1;
    }

    pool->isdestroy = true;

    pthread_cond_broadcast(&(pool->queue_ready));
    for(idx = 0; idx < pool->num; idx++)
    {
        ret pthread_kill(pool->threadid[idx], 0);
        if(ESRCH == ret)
        {
            continue;
        }
        else
        {
            idx--;
            sleep(1);
        }
    }

    free(pool->threadid);
    pool->threadid = NULL;

    while(NULL != pool->head)
    {
        member = pool->head;
        pool->head = member->next;
        free(member);
    }
    pthread_mutex_destroy(&(pool->queue_lock));
    pthread_cond_destroy(&(pool->queue_ready));
    free(pool);

    return 0;
 }

/******************************************************************************
 **函数名称: thread_create_detach
 **功    能: 创建分离线程
 **输入参数:
 **       pool: 线程池
 **       idx: 线程索引号
 **输出参数: NONE
 **返    回: 0: success !0: failed
 ******************************************************************************/
 int thread_create_detach(thread_pool_t *pool, int idx)
 {
    int ret = 0;
    pthread_attr_t attr;

    do
    {
        ret = pthread_attr_init(&attr);
        if(0 != ret)
        {
            return -1;
        }

        ret = pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
        if(0 != ret)
        {
            return -1;
        }

        ret = pthread_create(&((*pool)->threadid[idx]), &attr, thread_routine, *pool);
        if(0 != ret)
        {
            pthread_attr_destroy(&attr);
            if(EINTR == errno)
            {
                continue;
            }
            return -1;
        }
        pthread_attr_destroy(&attr);

    }while(0);

    return 0;
 }

 /*************************************************************
 **功  能：线程池各个线程入口函数
 **参  数：
 **    arg：线程池对象
 **返回值：0：成功 !0: 失败
 *************************************************************/
 void *thread_routine(void *arg)
 {
    thread_worker_t *worker = NULL;
    thread_pool_t *pool = (thread_pool_t*)arg;

    while(1)
    {
        pthread_mutex_lock(&(pool->queue_lock));
        while((false == pool->isdestroy) && (0 == pool->queue_size));
        {
            pthread_cond_wait(&(pool->queue_ready), &(pool->queue_lock));
        }

        if(false != pool->isdestroy)
        {
            pthread_mutex_unlock(&(pool->queue_lock));
            pthread_exit(NULL);
        }

        pool->queue_size--;
        worker = pool->head;
        pool->head = worker->next;
        pthread_mutex_unlock(&(pool->queue_lock));
        (*(worker->process))(worker->arg);

        free(worker);
        worker = NULL;
    }
 }


 #define THREAD_MAX_NUM 32
 #define SLEEP 10

 int myprocess(void *arg)
 {
    fprintf(stdout, "[%s][%d] threadid:%d arg:%d", __FILE__, __LINE__, phtread_self(), *(int*)arg);
    return 0;
 }

 int main(void)
 {
    int ret = 0, idx = 0;
    thread_pool_t *pool = NULL;
    int array[THREAD_MAX_NUM] = (0);

    ret = thread_pool_init(&pool, THREAD_MAX_NUM);
    if(ret < 0)
    {
        return -1;
    }

    for(idx = 0; idx < THREAD_MAX_NUM; idx++)
    {
        array[idx] = idx;
        thread_pool_add_worker(pool, myprocess, &array[idx]);
    }

    thread_pool_destroy(pool);
    pool = NULL;
    return 0;
 }

