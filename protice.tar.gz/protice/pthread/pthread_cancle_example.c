#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>

void *thread_function(void *arg);

int main(int argc, char *argv[])
{
    int res;
    pthread_t a_thread;
    void *thread_result;
    /*创建线程*/
    res = pthread_create(&a_thread, NULL, thread_function, NULL);
    if(res != 0)
    {
        perror("Thread creation failed");
        exit(1);
    }
    sleep(10);
    printf("cancelling thread...\n");
    res = pthread_cancel(a_thread);//取消子线程
    if(res != 0)
    {
        perror("Thread cancelation failed");
        exit(1);
    }
    printf("waiting for thread to finish..\n");
    /*等待子线程结束*/
    res = pthread_join(a_thread, &thread_result);
    if(res != 0)
    {
        perror("Thread join failed");
        exit(1);
    }

    exit(0);
}

void *thread_function(void *arg)
{
    int i, res, j;
    sleep(1);
    res = pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
    if(res != 0)
    {
        perror("Thread pthread_setcancelstate failed");
        exit(1);
    }

    sleep(3);
    printf("thread cancle type is disable, can't cancle this thread\n");
    for(i = 0; i < 3; i++)
    {
        printf("Thread is running (%d)...\n", i);
        sleep(1);
    }

    res = pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
    if(res != 0)
    {
        perror("Thread pthread_setcancelstate failed");
        exit(1);
    }
    else
        printf("Now change this canclestate is ENABLE\n");

    sleep(30);
    pthread_exit(0);
}
