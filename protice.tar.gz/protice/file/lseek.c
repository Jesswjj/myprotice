/*
#include <unistd.h>
off_t lseek(int filedes, off_t offset, int whence);
lseek函数的第一个参数是已经打开的文件描述符，第2个参数和第3个参数
1.当whence是SEEK—SET时，表示将该文件的文件偏移量设置为距文件开始位置offset个字节。不能是负数
2.当whence是SEEK—CUR时，表示将该文件的文件偏移量设置为当前文件偏移量增加offset个字节，offset的值可以是一个负数。
3.当whence是SEEK—END时，表示将该文件的文件偏移量设置为当前文件结尾位置增加offset个字节，offset的值可以是一个负数。
*/


#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

#define MAX 1024

int main(void)
{
    int fd;
    off_t off;
    char buf[MAX];

    fd = open("test.txt", O_RDWR);
    if(fd == -1)
    {
        perror("fail to open");
        exit(1);
    }

    printf("before reading\n");
    off = lseek(fd, 0, SEEK_CUR);
    if(off == -1)
    {
        perror("fail to lseek");
        exit(1);
    }

    printf("the offset is:%d\n", off);

    if(read(buf, 5, fd) == -1)
    {
        perror("fail to read");
        exit(1);
    }

    printf("the offset is :%d\n", off);
    close(fd);

    return 0;
}

