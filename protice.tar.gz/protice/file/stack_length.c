#include <stdlib.h>
#include <stdio.h>

#define Stack_Length 6
#define OK 1
#define ERROR 0

typedef int selemtype;
/*存储形式*/
typedef struct snode
{
    selemtype data;
    struct Snode *next;
}Snode, *Linkstack;
/*函数名
参数：
作用：建立一个空栈
*/

void createtwo(Linkstack head, int n)
{
    int i;
    Snode *p;/*定义心结点指针*/
    /*建立带头节点的线性链表*/
    head = (Linkstack)malloc(sizeof(Snode));
    head->next = NULL;

    printf("Please input the data for Linkstack Node:\n");
    for(i = n; i > 0; --i)
    {
        p = (Snode*)malloc(sizeof(Snode));/*为新结点申请空间，即创建一新结点*/
        scanf("%d", &p->data);
        p->next = head->next;
        head->next = p;
    }

}

int push(Linkstack top, selemtype e)
{
    Snode *q;
    q = (Linkstack)malloc(sizeof(Snode));

    if(!q)
    {
        printf("overfolow!\n");
        return (ERROR);
    }
    q->data = e;
    q->next = top->next;
    top->next = q;

    return (OK);
}

int pop(Linkstack top, selemtype e)
{
    Snode *q;
    if (!top->next)
    {
    	printf("error\n");
    	return (ERROR);
    }
    e = top->next->data;
    free(q);
    return (OK);
}

void main(int argc, char const *argv[])
{
	int e;
	/**/
	Linkstack top;
	createtwo(top, 3);

	Linkstack p;
	printf("\nThe old Linkstack is (top to bottom):\n");
	p = top;
	while(p->next)
	{
		p = p->next;
		printf("%d", p->data);
	}
	printf("\nplease input the data to push:\n");
	scanf("%d", &e);

	if(push(top, e))
	{
		printf("success to push\n");
	}

	printf("The new Linkstack is :\n");
	while(top->next)
	{
		top = top->next;
		printf("%d ", top->data);
	}
	return 0;
}
