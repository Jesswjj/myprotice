#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NUM 20
void main()
{
    struct stu
    {
        long iNum;
        char chpName[10];
        float fScore;
    }clas[NUM], max;

    FILE *stream;
    int i;
    float fMax;
    char str[20];

    stream = fopen("docu", "w");
    for(i = 0; i < NUM; i++)
    {
        printf("\n输入第%d个人的姓名", i);
        gets(clas[i].chpName);
        printf("\n输入第%d个人的学号", i);
        gets(str);
        clas[i].iNum = atoi(str);
        printf("\n输入第%d个人的成绩", i);
        gets(str);
        clas[i].fScore = atof(str);
    }

    fwrite(clas, sizeof(struct stu), NUM, stream);

    fclose(stream);

    stream = fopen("docu", "r");
    fread(&max, sizeof(struct stu), 1, stream);
    fMax = max.fScore;
    for(i = 1; i < NUM; i++)
    {
        fread(&max, sizeof(struct stu), 1, stream);
        if(max.fScore > fMax)
            fMax = max.fScore;
    }
    printf("%f\n", fMax);
    fclose(stream);
}
