/*文件拷贝*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>

int main(int argc, char *argv[])
{
    int fd_src, fd_des;
    char buf[128];
    int num;

    if(argc != 3)//运行时，必须包括源文件，目标文件
    {
        printf("the format must be:cp file_src file_des");
    }

    if((fd_src = open(argv[1], O_RDONLY)) == -1)//以读方式打开源文件
    {
        perror("open");
        exit(1);
    }
    //以写方式打开目标文件
    if((fd_des = open(argv[2], O_CREAT|O_EXCL|O_WRONLY, 0644)) == -1)
    {
        perror("oepn2");
        exit(1);
    }

    do
    {
        num = read(fd_src, buf, 128);
        write(fd_des, buf, num);
    }while(num == 128);

    close(fd_src);
    close(fd_des);

}
