#include <stdio.h>
#include <stdlib.h>

void main()
{
    char s[80];
    int a;
    FILE *fp;

    if((fp = fopen("text.txt", "r")) == NULL)
    {
        printf("Cannot open file");
        exit(1);
    }
    /*打开text.txt，如果出错，打印错误提示，终止程序运行*/
    fscanf(fp, "%s%d", s, &a);
    /*从文件中，以"%s %d"格式输入一个字符串和一个整形值给s和a*/
    printf("%s, %d\n", s, a);
}
