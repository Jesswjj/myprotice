#include <stdio.h>

int main()
{
    FILE *in, *out;
    char str[10];

    if((in = fopen("file1.txt", "rt")) == NULL)
    {
        printf("Open File Error!\n");
        exit(0);
    }
    if((out = fopen("file2.txt", "w+")) == NULL)
    {
        printf("Open file error!\n");
        exit(0);
    }

    while(!feof(in))
        fputc(fgetc(in), out);

    fclose(in);
    fclose(out);
    return 0;
}
