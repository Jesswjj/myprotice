/*创建一个新文件
#include <fcntl.h>
int creat(const char *pathname, mode_t mode)
该函数的第一个参数和open函数的参数相同意义，第2个和第3个参数等效
成功返回1,失败返回-1
creat函数只能以只写方式打开新创建的文件，不能读
*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

int main(void)
{
    int fd;
    fd = creat("test.txt", 0700);
    if(fd == -1)
    {
        perror("fail to creat");
        exit(1);
    }
    else
        printf("creat OK\n");

    return 0;
}
