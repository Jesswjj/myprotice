#include <stdio.h>
#include <stdlib.h>
void main()
{
    FILE *fp;                           /*定义文件指针*/
    char str[100];
    int i = 0;
    if((fp = fopen("file2.txt", "w")) == NULL) /*只写打开文件*/
    {
        printf("Can not open the file2.\n");
        exit(0);
    }

    printf("Input a string:");
    scanf("%s", str);
    while(str[i])
    {
        if(str[i] >= 'a' && str[i] <= 'z')
            str[i] = str[i] - 32;
        fputc(str[i], fp);                      /*输出到fp*/
        i++;
    }

    fclose(fp);                                 /*关闭文件*/
    fp = fopen("file2.txt", "r");
    fgets(str, 100, fp);
    printf("%s", str);
    fclose(fp);
}
