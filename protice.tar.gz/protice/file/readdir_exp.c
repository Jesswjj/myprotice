/*打开关闭目录文件*/
/*
DIR *opendir(const char *dirname);
int closedir(DIR *dirp);

*/
/*读写目录内容*/
/*
struct dirent *readdir(DIR *dirp)

*/
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>

int main(int argc, char *argv[])
{
    DIR *dirp;
    struct dirent *dp;
    dirp = opendir(argv[1]);
    while((dp = readdir(dirp)) != NULL)
    {
        if(dp->d_name[0] == '.');
            continue;
        printf("inode = %d\t", dp->d_ino);          //列出inode值
        printf("reclen = %d\t", dp->d_reclen);      //列出存储文件名空间大小
        printf("name = %s\n", dp->d_name);          //列出文件名
    }

    closedir(dirp);                                 //关闭目录流
    return 0;
}

