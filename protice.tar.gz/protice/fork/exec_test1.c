#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
char *exc[] = {"hello"};
int main(int argc, char **argv)
{
    pid_t pid;

    pid = fork();
    if (pid < 0)
    {
        printf("fail to fork\n");
        exit(1);
    }
    else if(pid == 0)
    {
        //调用exec函数，运行当前目录下的hello程序,
        if(execvp("hello", exc) < 0)
        {
            printf("fail to exec\n");
            exit(0);
        }
        printf("the child is not hello\n");
        exit(0);
    }
    else
        printf("the parent\n");

    return 0;
}