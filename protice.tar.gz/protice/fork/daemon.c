#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/syslog.h>
#include <sys/param.h>
#include <time.h>
#include <string.h>

int main(int argc, char **argv)
{
    // 1、fork()创建子进程，父进程exit()退出
    pid_t pid = fork();
    if (pid == -1)
    {
        printf("fork err\n");
        exit(0);
    }
    if (pid > 0)
    {
        printf("parent exit\n");
        exit(0);
    }
    // 2、在子进程中调用 setsid() 函数创建新的会话
    // 新建会话，成功返回值是会话首进程id，进程组id ，首进程id
    pid = setsid();//不能再终端中打印了
    if(pid == -1)
    {
        exit(0);
    }
    // 3、再次 fork() 一个子进程并让父进程退出。
    pid = fork();
    if (pid > 0)
    {
        exit(0);
    }
    // 关闭打开的文件描述符
    int i;
    for(i = 0; i < 3; ++i)
        close(i);
    open("/dev/null", O_RDONLY);
    open("/dev/null", O_RDWR);
    open("/dev/null", O_RDWR);
    // 4、在子进程中调用 chdir() 函数，让根目录 ”/” 成为子进程的工作目录,这里测试用tmp
    chdir("tmp");
    // 5、在子进程中调用 umask() 函数，设置进程的文件权限掩码为0
    umask(0);
    time_t ticks;
    int fd;
    while(1)
    {
        sleep(1);

		fd = open("./daemon.log", O_WRONLY | O_CREAT | O_APPEND, 0644);
        if(fd == -1)
        {
            printf("open error\n");		
        }		
        ticks = time(0);		
        char *buf = asctime(localtime(&ticks));
        write(fd, buf, strlen(buf));
        close(fd);
    }
    return 0;
}