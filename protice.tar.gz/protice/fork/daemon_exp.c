#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/syslog.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
/*
守护进程编写过程
1：屏蔽一些有关控制终端操作的信号，这是为了防止在守护进程没有正常运行起来前，控制终端受到干扰挂起
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);
    signal(SIGHUP,  SIG_IGN);
2：在后台运行
3：脱离控制终端和进程组
4：禁止进程重新打开控制终端
5：关闭打开的文件描述符
6：改变当前工作目录
7：重设文件创建掩码
8：处理SIGCHLD信号（子进程退出信号）
*/

int init_deamon(const char *pname, int facility)
{
    int pid;
    int i;
    //处理可能的终端信号
    signal(SIGTTOU, SIG_IGN);
    signal(SIGTTIN, SIG_IGN);
    signal(SIGTSTP, SIG_IGN);
    signal(SIGHUP,  SIG_IGN);


    if(pid = fork())            //创建子进程，父进程退出
    {
        perror("fork");
        exit(1);
    }
    setsid();                   //设置新会话组长，新进程组长，脱离终端
    if(pid = fork())            //创建新进程，子进程不能再申请终端
        exit(1);
    else if(pid < 0)
    {
        perror("fork");
        exit(1);
    }
    for(i = 0; i < NOFILE; ++i)
        close(i);

    open("/dev/null", O_RDONLY);
    open("/dev/null", O_RDWR);
    open("/dev/null", O_RDWR);


    chdir("tmp");
    umask(0);
    signal(SIGCHLD, SIG_IGN);
    openlog(pname, LOG_PID, facility);
    return ;

}

int main(int argc, char *argv[])
{
    FILE *fp;
    time_t ticks;
    init_deamon(argv[0], LOG_KERN);
    while(1)
    {
        sleep(1);
        ticks = time(NULL);
        syslog(LOG_INFO, "%s", asctime(localtime(&ticks)));
    }
}
