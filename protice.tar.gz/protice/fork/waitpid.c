#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char*argv[])
{
    pid_t pid, w;
    int status;
    char *message;
    printf("begin fork\n");

    pid = fork();
    switch(pid)
    {
        case -1:
                perror("fork failed");
                exit(1);
        case 0:
                message = "This is the child";
                printf("%s: pid = %d\n", message, getpid());
                if(argc == 1)
                pause();
                _exit(atoi(argv[1]));
                break;
        default:
            message = "This is the parent";
            break;
    }
    printf("%s:pid = %d\n", message, getpid());

}
