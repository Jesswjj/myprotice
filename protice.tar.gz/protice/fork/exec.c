#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main()
{
    pid_t pid;
    const char *usr_envp[] = {"MYDEFINE=unknown", "PATH=/tmp", 0};

    printf("begin fork()\n");
    pid = fork();

    switch(pid)
    {
        case -1:
            perror("fork fialed");
            exit(1);
        case 0:
            if(execle("/tmp/child1", "myarg1", "my arg2", (char*)0, env_init) < 0)
                perror("execle fialed");
            break;
        default:
            break;
    }
    if(waitpid(pid, NULL, 0) < 0)
        perror("waitpid failed");
    printf("parent exiting\n");
    exit(0);
}
