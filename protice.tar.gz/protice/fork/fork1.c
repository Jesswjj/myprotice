#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main()
{
    pid_t pid;
    char *message;
    int n = 6;

    printf("fork program starting\n");
    pid = fork();

    switch(pid)
    {
        case -1:
            perror("fork failed");
            exit(1);
        case 0:
            message = "This is the child";
            n++;
            break;
        default:
            message = "This is the parent";
            n--;
            break;
    }
    printf("%s: pid = %d, n = %d\n", message, getpid(), n);

    exit(0);
}

