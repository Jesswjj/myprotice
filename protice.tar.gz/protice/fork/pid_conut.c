#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv)
{
    pid_t pid;
    int count = 0;
    pid = fork();

    count++;
    printf("pid:%d, count = %d\n", getpid(), count);

    return 0;
}