#include <stdio.h>
//用gcc -S编译查看是否集成在一个函数里面
inline int add(int a, int b)
{
    return a+b;
}

int main(void)
{
    int c;
    c = add(1, 2);
    
    return 0;
}