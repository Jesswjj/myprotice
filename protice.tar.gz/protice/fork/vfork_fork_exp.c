/*在以下程序中使用vfork函数创建子进程，子进程对全局变量和原父亲进程的局部变量进行修改，
然后中父子进程中分别打印修改后变量，由结果可以看出，父子进程共享空间*/
#include <unistd.h>
#include <stdio.h>
#include <error.h>
#include <sys/types.h>
#include <stdlib.h>

int glob = 6;   //全局已经初始化变量，位于数据段中
int main()
{
    int var;
    pid_t pid;
    var = 88;           //局部变量，位于栈空间中
    printf("in beginning:\tglob = %d\tvar = %d\n", glob, var);

    if((pid = vfork()) < 0)
    {
        perror("vfork");
        exit(1);
    }
    else if(pid == 0)           //子进程中
    {
        printf("in child, modify the var:glob++, var++\n");
        glob++;                 //子进程中修改全局变量
        var++;                  //子进程中修改全局变量
        printf("in child:\tglob = %d\tvar = %d\n", glob, var);
        _exit(0);               //使用-exit()退出

    }
    else
    {                           //父进程打印
        printf("in parent:\tglob = %d\tvar = %d\n", glob, var);
        return 0;
    }
}
