#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include<sys/file.h>

/*
 * typedef struct flock flock;
 *
 *
 * void lock_init(flock *lock, short type, short whence, off_t start, off_t len)
 * {
 *     if (lock == NULL)
 *         return;
 *
 *     lock->l_type = type;
 *     lock->l_whence = whence;
 *     lock->l_start = start;
 *     lock->l_len = len;
 * }
 */

/*
 * int readw_lock(int fd)
 * {
 *     if (fd < 0)
 *     {
 *         return -1;
 *     }
 *
 *     struct flock lock;
 *     lock_init(&lock, F_RDLCK, SEEK_SET, 0, 0);
 *
 *     if (fcntl(fd, F_SETLKW, &lock) != 0)
 *     {
 *         return -1;
 *     }
 *
 *     return 0;
 * }
 */


int main()
{
    int lockfd = open("./read", O_RDWR | O_CREAT, 0666);
    printf("go to getlock...\n");
/*     while(1)
 *     {
 *         if(readw_lock(fd) == 0)
 *             printf("get readlock\n");
 *         else
 *             printf("try to get lock");
 *
 *         sleep(5);
 *     }
 */

    int ret = flock(lockfd,LOCK_EX|LOCK_NB);
    if (ret == -1)
    {
        return -3;
    }
    sleep(50);

    return 0;
}
