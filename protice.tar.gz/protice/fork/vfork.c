#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <error.h>
#include <stdlib.h>

int glob = 6;
int main(int argc, char **argv)
{
    int state;
    int var=88;
    printf("in begining:\tglob=%d\tvar=%d\n", glob, var);

    pid_t vpid = vfork();
    if (vpid < 0)
    {
        perror("vfork");
        exit(EXIT_FAILURE);
    }
    else if(vpid == 0)
    {
        printf("in child, modify the var:glob++, var++\n");
        glob++;
        var++;
        printf("in child:\tglob=%d\tvar=%d\n", glob, var);
        exit(0);
    }
    else
    {
        // printf("in parent, modify the var:glob++, var++\n");
        // glob++;
        // var++;
        printf("in parent:\tglob=%d\tvar=%d\n", glob, var);
        return 0;
    }

    return 0;
}