#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
int main(int argc, char **argv)
{
    int test = 0;
    pid_t processid = fork();
    pid_t id;
    if (processid == -1)
    {
        printf("create pid error\n");
        return 0;
    }
    if (processid == 0)
    {
        test = 2;
        printf("child my pid:%d, my perent pid:%d, my group pid:%d\n", getpid(), getppid(), getpgid(processid));
        sleep(2);
    }
    else
    {
        test = 1;
        printf("parent my pid:%d, my perent pid:%d, my group pid:%d\n", getpid(), getppid(), getpgid(processid));
        sleep(1);
        id = wait(&test);   //参数被修改成子进程退出时的值，返回的是哪一个子进程退出
    }
    printf("test %d, id=%d\n", test, id);
    
    //exit(1);    //父进程获取返回值是n*256
    return 0;
}