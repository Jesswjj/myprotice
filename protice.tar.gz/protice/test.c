#include <stdio.h>

int main()
{

	printf("hello, ");
	printf("world\n");

	int j = 0;
	int i = j;
	printf("%d\n", j++);
	printf("%d\n", i+1);


	return 0;
}
