#include <stdio.h>

void main()
{
    int array[16][16];
    int i, j, k, m, n;

    m = 1;
    while(m == 1)
    {
        printf("请输入n(n<n<=15), n是奇数)\n");
        scanf("%d", &n);
        if((n!=0) && (n<=15) && (n%2 != 0))
        {
            printf("矩阵阶数是 %d\n", n);
            m = 0;
        }
    }
    //数组赋初值为0
    for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
            array[i][j] = 0;
    //建立魔方阵
    j = n/2 + 1;
    array[1][j] = 1;
    for(k=2; k<=n*n; k++)
    {
        i = i-1;        //行数减少1
        j = j+1;        //列数增加1
        if((i<1) && (j>n))
        {
            i = i + 2;  //行数增加2
            j = j - 1;  //列数减少1
        }
        else
        {
            if(i < 1)   //如果行数小于，则跳转到第n行
                i = n;
            if(j > n)   //如果列数大于n,则回到第一列
                j = 1;
        }
        if(array[i][j] == 0)
            array[i][j] = k;
        else
        {
            i = i + 2;
            j = j - 1;
            array[i][j] = k;
        }
    }

    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++)
            printf("%5d", array[i][j]);
        printf("\n");
    }
}
