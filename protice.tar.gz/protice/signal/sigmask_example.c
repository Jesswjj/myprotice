#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
//进程屏蔽信号应用
static void sig_quit(int);

/*
extern int sigprocmask(int , sigset_t , sigset*)
第一个参数
SIG——BLOCK 0 将第二个参数所描述的集合添加到当前进程屏蔽的信号集
SIG——UNBLOCK 1 将第二个参数所描述的集合从当前进程屏蔽的信号集中删除
SIG——SIGSETMASK 2 无论之前屏蔽流那些信号，设置当前进程屏蔽的集合为第二个参数
*/


int main(int argc, char **argv)
{
    sigset_t newmask, oldmask, pendmask;
    if(signal(SIGQUIT, sig_quit) == SIG_ERR)        //安装信号处理函数
    {
        perror("signal");
        exit(1);
    }

    printf("install sig_quit\n");
    sigemptyset(&newmask);              //清空所有信号集体
    sigaddset(&newmask, SIGQUIT);       //添加SIGQUIT信号到信号集中

    if(sigprocmask(SIG_BLOCK, &newmask, &oldmask) < 0)   //设置进程屏蔽newmask,原来值读到oldmask
    {
        perror("signalmask");
        exit(1);
    }

        printf("block SIGQUIT, wait 15 second\n");
        sleep(15);                              //等待15秒
    if(sigpending(&pendmask) < 0)               //保存屏蔽信号
    {
        perror("sigpending");
        exit(1);
    }
    if(sigismember(&pendmask, SIGQUIT));        //检测SIGQUIT是否在信号集中
        printf("\nSIGQUIT pending\n");
    if(sigprocmask(SIG_SETMASK, &oldmask, NULL) < 0)    //替换进程掩码，集清楚屏蔽SIGQUIT
    {
        perror("sigprocmask");
        exit(1);
    }

    printf("SIGQUIT ubblocked\n");
    sleep(15);
    return 0;

}

static void sig_quit(int signo)
{
    printf("caught SIGQUIT, the process will quit\n");
    if(signal(SIGQUIT, SIG_DFL) == SIG_ERR)         //再次安装
    {
        perror("signal");
        exit(1);
    }
}
