#include <stdio.h>
#include <unistd.h>
#include <signal.h>
//signal安装信号函数第一个参数是sig接收到的信号，第二个参数为接收到信号后的处理代码入口（调用的函数）

void sig_usr(int sig);
int main(int argc, char **argv)
{
    int i = 0;
    if(signal(SIGUSR1, sig_usr) == SIG_ERR)
        printf("cannot catch SIGUSR1\n");

    if(signal(SIGUSR2, sig_usr) == SIG_ERR)
        printf("cannot catch SIGUSR2\n");

    while(1)
    {
        printf("%2d\n", i);
        pause();
            i++;
    }
    return 0;
}

void sig_usr(int sig)
{
    if(sig == SIGUSR1)
        printf("Received SIGUSR1\n");
    else if(sig == SIGUSR2)
        printf("Received SIGUSR2\n");

    else
        printf("Undeclared signal %d\n", sig);
}
