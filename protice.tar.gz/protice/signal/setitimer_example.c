#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <signal.h>
/*
函数getitimer()和setitimer()根据逝去时间，在用户空间执行时间，总的执行事件来设置读出超时定时器信息，
定时器将在超时后产生相应的信号
系统为每个进程提供3个定时器，也是这两个函数的第一个参数可选项
ITIMER—REAL:以逝去事件递减，当时钟到来后产生SIGALRM信号。
ITIMER—VIRTUAL：当进程自身代码执行是递减，当时钟到来时产生SIGVTALRM信号
ITIMER—PROF：当进程自身执行或是系统在执行进程的系统调用时递减，当时钟超时时将产生SIGPROF信号，可
联合ITIMER-VIRTUAL用来计算进程在用户空间和系统空间的运行时间。
*/

int main(void)
{
    struct itimerval setvalue;
    setvalue.it_interval.tv_sec = 3;
    setvalue.it_interval.tv_usec = 0;
    setvalue.it_value.tv_sec = 3;
    setvalue.it_value.tv_usec = 0;
    setitimer(ITIMER_REAL, &setvalue, NULL);

    setvalue.it_interval.tv_sec = 3;
    setvalue.it_interval.tv_usec = 0;
    setvalue.it_value.tv_sec = 3;
    setvalue.it_value.tv_usec = 0;
    setitimer(ITIMER_VIRTUAL, &setvalue, NULL);

    setvalue.it_interval.tv_sec = 3;
    setvalue.it_interval.tv_usec = 0;
    setvalue.it_value.tv_sec = 3;
    setvalue.it_value.tv_usec = 0;
    setitimer(ITIMER_PROF, &setvalue, NULL);

    while(1)
    {
        struct itimerval value;
        getitimer(ITIMER_REAL, &value);
        printf("ITIMER_REAL:internal:%ds%dms, remain:%ds%dms\n",
        value.it_interval.tv_sec, value.it_interval.tv_usec, value.it_value.tv_sec, value.it_value.tv_usec);
        sleep(1);
    }
}
