#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <errno.h>


void pr_mask(char *str)
{
    sigset_t sigset01;
    int errno_save;

    if(sigprocmask(0, NULL, &sigset01) < 0)
        perror("sigprocmask erro!");
        printf("%s\n", str);
    if(sigismember(&sigset01, SIGINT))
        printf("SIGINT\n");
    if()
}
