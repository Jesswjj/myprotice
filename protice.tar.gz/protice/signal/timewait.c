#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>

void alarm_handler(int signo)
{
    ;
}
/*有限等待的read函数，参数和返回值和read函数一样*/
size_t sig_read(int filefds, void *buf, size_t nbytes)
{
    size_t n;
    /*加载SIGALARM的处理函数*/
    if(signal(SIGALRM, alrm_handler) == SIG_ERR)
    {
        perror("fail to set handler for SIGALRM");
        exit(1);
    }

    alarm(5);/*设置定时器，只等待5秒钟*/

    if((n = read(filefds, buf, nbytes)) == -1)/*开始读操作，如果超时被中断，read函数返回-1*/
    return -1;

    alarm(0);/*如果读成功，则取消定时器*/

    return n;
}

void alarm_handler(int signo)
{
    ;
}

size_t sig_read(int filefds, void *buf size_t nbytes)
{
    size_t n;
}
