#include <stdio.h>
#include <signal.h>
#include <stdlib.h>

static void sig_quit(int);

int main()
{
    sigset_t newmask, oldmask, pendmask;        //定义信号集
    if(signal(SIGQUIT, sig_quit) == SIG_ERR)
    {
        perror("signal");
        exit(1);
    }
    printf("install sig_quit\n");
    sigemptyset(&newmask);                      //清空信号集
    sigaddset(&newmask, SIGQUIT);               //添加SIGQUIT到信号集中

    if(sigprocmask(SIG_BLOCK, &newmask, &oldmask) < 0)
    {                                           //设置进程阻塞newmask,原来读到oldmask
        perror("signalmask");
        exit(1);
    }
        printf("block SIGQUIT, wait is second\n");
        sleep(15);                              //等待15秒
    if(sigpending(&pendmask) < 0)               //保存阻塞信号
    {
        perror("sigpending");
        exit(1);
    }
    if(sigismember(&pendmask, SIGQUIT))
        printf("\nSIGQUIT pending\n");
    if(sigprocmask(SIG_SETMASK, &oldmask, NULL) < 0)
    {
        perror("sigprocmask");
        exit(1);
    }
    printf("SIGQUIT unblocked\n");
    sleep(15);
    return 0;
}

static void sig_quit(int signo)                               //信号处理函数
{
    printf("caught SIGQUIT, the process will quit\n");
    if(signal(SIGQUIT, SIG_DFL) == SIG_ERR)                   //再次安装
    {
        perror("signal");
        exit(1);
    }
}


