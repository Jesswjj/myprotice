#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <stdlib.h>

void handler()
{
    printf("int hello\n");
}

int main()
{
    int i;
    signal(SIGALRM, handler);
    printf("%d\n", ualarm(5, 2000));

    while(1)
    {
        sleep(1);
        printf("test\n");

    }
}
