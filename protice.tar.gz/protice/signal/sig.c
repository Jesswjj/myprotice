/*子进程先向父进程发送SIGUSR1信号，父进程向子进程发送SIGUSR2信号*/

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

void handler(int signo)
{
    switch(signo)
    {
    case SIGUSR1:
        printf("Parent:catch SIGUSR1\n");
        break;
    case SIGUSR2:
        printf("child:catch SIGUSR2\n");
    default:
        printf("should not be here\n");
        break;
    }

    return ;
}

int main(void)
{
    pid_t ppid, cpid;
    /*为两个信号设置处理程序*/
    if(signal(SIGUSR1, handler) == SIG_ERR)
    {
        perror("can't set handler for SIGUSR1");
        exit(1);
    }

    if(signal(SIGUSR2, handler) == SIG_ERR)
    {
        perror("can't set handler for SIGUSR2");
        exit(1);
    }

    ppid = getpid();

    if((cpid = fork()) < 0)
    {
        perror("fail to fork");
        exit(1);
    }
    else if(cpid == 0)/*子进程*/
    {
        if(kill(ppid, SIGUSR1) == -1)
        {
            perror("fail to send signal");
            exit(1);
        }
        while(1);
    }
    else
    {
        sleep(2);

        if(kill(cpid, SIGUSR2) == -1)
        {
            perror("fail to send signal");
            exit(1);
        }

        printf("kill child\n");
        //sleep(1);
        if(kill(cpid, SIGKILL) == -1)
        {
            perror("fail to send signal");
            exit(1);
        }
        if(wait(NULL) == -1)
        {
            perror("fail to wait");
            exit(1);
        }

    }

    return 0;
}
