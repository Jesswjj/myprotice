#ifndef __THREAD_POOL_H
#define __THREAD_POOL_H

#include <pthread.h>

typedef void *(*pool_task_f)(void *arg);

typedef struct _task
{
    pool_task_f process;
    void *arg;
    struct _task *next;
}pool_task;

typedef struct
{
    pthread_t *threadid;
    int threads_limit;
    int destroy_flag;
    pool_task *queue_head;
    int task_in_queue;
    pthread_mutex_t queue_lock;
    pthread_cond_t queue_ready;
}pool_t;
/*********************************************************************
*功能:        初始化线程池结构体并创建线程
*参数:
            pool：线程池句柄
            threads_limit：线程池中线程的数量
*返回值:   无
*********************************************************************/
void pool_init(pool_t *pool, int thread_limit);
/*********************************************************************
*功能:        销毁线程池，等待队列中的任务不会再被执行，
            但是正在运行的线程会一直,把任务运行完后再退出
*参数:        线程池句柄
*返回值:   成功：0，失败非0
*********************************************************************/
int pool_uninit(pool_t *pool);
/*********************************************************************
*功能:        向线程池中添加一个任务
*参数:
            pool：线程池句柄
            process：任务处理函数
            arg：任务参数
*返回值:   0
*********************************************************************/
int pool_add_task(pool_t *pool, pool_task_f process, void *arg);

#endif // __THREAD_POOL_H
