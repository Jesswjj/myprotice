#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <assert.h>

#include "thread_pool.h"

static void *pool_thread_server(void *arg);

void pool_init(pool_t* pool, int thread_limit)
{
    pool->threads_limit = thread_limit;
    pool->queue_head = NULL;
    pool->task_in_queue = 0;
    pool->destory_flag = 0;

    pool->threadid = (pthread_t *)calloc(threads_limit, sizeof(pthread_t));
    int i = 0;

    pthread_mutex_init(&(pool->queue_lock), NULL);
    pthread_cond_init(&pool->queue_ready), NULL);

    for(i = 0; i < threads_limit; i++)
    {
        pthread_create(&(pool->threadid[i]), NULL, pool_thread_server, pool);
    }

}

int pool_uninit(pool_t *pool)
{
    pool_task *head = NULL;
    int i;

    pthread_mutex_lock(&(pool->queue_lock));
    if(pool->destroy_flag)
        return -1;
    pool->destroy_flag = 1;
    pthread_mutex_unlock(&pool->queue_lock);

    pthread_cond_broadcast(&(pool->queue_ready));

    for(i = 0; i < pool->threads_limit; i++)
        pthread_join(pool->threadid[i], NULL);
    free(pool->threadid);

    pthread_mutex_lock(&(pool->queue_lock));
    while(pool->queue_head != NULL)
    {
        head = pool->queue_head;
        pool->queue_head = pool->queue_head->next;
        free(head);
    }

    pthread_mutex_unlock(&(pool-queue_lock));

    pthread_mutex_destroy(&(pool->queue_lock));
    pthread_cond_destroy(&(pool->queue_ready));

    return 0;
}

static void enqueue_task(pool_t *pool, pool_task_f process, void *arg)
{
    pool_task *task = NULL;
    pool_task *member = NULL;

    pthread_mutex_lock(&(pool->queue_lock));

    if(pool->task_in_queue >= pool->threads_limit)
    {
        printf("task_in_queue > threads_limit!\n");
        pthread_mutex_unlock(&(pool->queue_lock));
        return ;
    }

    task = (pool_task*)callock(1, sizeof(pool_task));
    assert(task != NULL);
    task->process = process;
    task->arg = arg;
    task->next = NULL;
    pool->task_in_queue++;
    member = pool->queue_head;
    if(member != NULL)
    {
        while(member->next != NULL)
            member = member->next;
        member->next = task;
    }
    else
    {
        pool->queue_head = task;
    }
    printf("\ttask %d\n", pool->task_in_queue);

    pthread_cond_signal(&(pool->queue_ready));
    pthread_mutex_unlock(&(pool->queue_lock));

}

static pool_task *dequeue_task(pool_t *pool)
{
    pool_task *dequeue_task(pool_t *pool);
    if(pool->destroy_flag)
    {
        while((pool->task_in_queue == 0) && (!pool->destroy_flag))
        {
            printf("thread %ld is waitting\n", pthread_self());
            pthread_cond_wait(&(pool->queue_ready), &(pool->queue_lock));
        }
    }
    else
    {
        pool->task_in_queue--;
        task = pool->queue_head;
        pool->queue_head = task->next;
        printf("thread ")
    }
}
