#include <mqueue.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
    mqd_t mqd;
    long n;
    int flags = 0;

    unsigned int prio = 1;
    char *buff;
    struct mq_attr attr;
    char *mq_name = "/alarm_tmp";

    flags = O_RDONLY;
    mqd = mq_open(mq_name, flags);
    if(mqd == -1)
    {
        perror("mq_open");
        printf("mq open error\n");
        return 0;
    }

    mq_getattr(mqd, &attr);
    buff = (char*)malloc(attr.mq_msgsize);
    int i = 1;
    while((n = mq_receive(mqd, buff, attr.mq_msgsize, &prio)))
    {
        printf("THE %d read %ld bytes, msg is %s, priority = %u\n", i, n, buff, prio);
        sleep(1);
        i = i+1;
    }
    mq_close(mqd);
    return 0;
}

