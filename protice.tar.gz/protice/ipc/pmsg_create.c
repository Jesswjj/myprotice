#include <mqueue.h>
#include <sys/stat.h>
#include <fcntl.h>


static void usageerror(const char *progname)
{
    fprintf(stderr, "usage:%s[-cx] [-m maxmsg] [-s msgsize] mq-name " "[octal-perms]\n", progname);
    fprintf(stderr, "-c        create queue(O_CREAT)\n");
    fprintf(stderr, "-m maxmsg set maximum # of message\n");
    fprintf(stderr, "-s msgsize set maximum message size\n");
    fprintf(stderr, "-x        create exclusively(O_EXCL)\n");
    exit(1);
}

int main(int aragc, char *argv[])
{
    int flags, opt;
    mode_t perms;
    mqd_t mqd;
    struct mq_attr attr, *attrp;

    attrp = NULL;
    attr.mq_maxmsg = 50;
    attr.mq_msgsize = 2048;
    flags = O_RDWR;

    while ((opt = getopt(argc, argv, "cm:s:x")) != -1)
    {
        switch(opt)
        {
            case 'c':
                flags |= O_CREAT;
                break;
            case 'm':
                attr.mq_maxmsg = atoi(optarg);
                attrp = &attr;
                break;
            case 's':
                attr.mq_msgsize = atoi(optarg);
                attrp = &attr;
            case 'x':
                flags |= O_EXCL;
                break;
            default:
                usageerror(argv[0]);
        }
    }

    if(optind >= argc)
        usageerror(argv[0]);

    perms = (argc <= optind + 1) ? (S_IRUSR | S_IWUSR):getInt(argv[optind + 1], GN_BASE_8, "octal-perms");

    mqd = mq_open(argv[optind], flags, perms, attrp);
    if(mqd == (mqd_t) - 1)
        perror("mq_open");

    exit(1);
}
