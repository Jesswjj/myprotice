#include <stdio.h>
#include <stdlib.h>


#define MAX_EPOLL_SIZE 100
#define THREADS_COUNT 10
/**/
char smtp_cmd_format;
struct epoll_event ev, events[MAX_EPOLL_SIZE];
int kdpfd, nfds;

struct block_queue
{
    int queue[THREADS_COUNT];
    long size;
    pthread_cond_t cond;
    pthread_mutex_t mutex;
}block_queue_t;

block_queue_t bq;

struct block_queue_param
{
    void *func;
    void *queue;
}block_queue_param_t;

void *block_queue(void *param)
{
    void(*func)(void*);
    int fd, i;

    block_queue_t* bque = (block_queue_param_t*)param->queue;

    func = (block_queue_param_t*)param->func;

    for(;;)
    {
        pthread_mutex_lock(bque->nutex);

        pthread_cond_wait(bque->cond, bque->mutex);

        if(bque->size == 0)
        {
        }
        else
        {
            fd = bque->queue[0];
            for(i = 0; i < bque->size; ++i)
                bque->queue[i] = bque->queue[i+1];
                bque->queue[bque->size-1] = 0;
            bque->size--;
                func(fd);
        }
        pthread_mutex_unlock(bque->mutex);
    }
}

void insert_queue(struct block_queue *bque, int fd)
{
    pthread_mutex_lock(bque->mutex);

    if(bque->size == THREADS_COUNT)
        return ;

    bque->queue[bque->size+1] = fd;
    if(++bque->size > THREADS_COUNT)
    {
        fprintf(stderr, "queue size over folow.%d", bque->size);
        exit 1;
    }

    pthread_cond_signal(bque->cond);
    pthread_mutex_unlock(bque->mutex);

}

int init_threads()
{
    size_t i = 0;
    block_queue_param_t bqp;

    bqp.func = (void*)smtp_echo;
    bqp.queue = (void*)bq;
    pthread_cond_init(bqp.cond, NULL);
    pthread_mutex_init(bqp.mutex, NULL);
    for(i = 0; i < THREADS_COUNT; ++i)
    {
        pthread_t child_thread;
        pthread_attr_t child_thread_attr;
        pthread_attr_init(&child_thread_attr);
        pthread_attr_setdetachstate(&child_thread_attr, PTHREAD_CREAT_DETACHED);
        if(pthread_create(&child_thread, &child_thread_attr, block_queue, (void *)bqp) < 0)
        {
            printf("pthread_create failed:%s\n", strerror(errno));
            return 1;
        }

        else
        {
            printf("pthread_create success:%d\n", (int)child_thread);
            return 0;
        }

    }
}


int handler(void *fd)
{
    printf("handler:fd =>%d\n", *(int*)(fd));
    insert_queue(&hq, fd);
    return 0;
}


int main(int argc, char *argv)
{
    int server_socket = init_smtp();
    int n;

    if(init_threads() == 0)
        printf("success full init_threads.");

    smtp_cmd_format = "^([a-zA-Z0-9]) (.*)$";
    kdpfd = epoll_create(MAX_EPOLL_SIZE);
    ev.events = EPOLLIN | EPOLLET;
    ev.data.fd = server_socket;
    if(epoll_ctl(kdpfd, EPOLL_CTL_ADD, server_socket, &ev) < 0)
    {
        fprintf(stderr, "epoll set insertion error: fd = %d < 0",
            server_socket);
    }
}
