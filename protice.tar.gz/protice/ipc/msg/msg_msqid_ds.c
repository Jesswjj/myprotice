#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

int main(int argc, char *argv[])
{
	key_t key;
	int msqid;
	struct msqid_ds buf;
	if((key=ftok(".", 'A')) == -1)
	{
		perror("ftok");
		exit(1);
	}
	if((msqid = msgget(key, 0666|IPC_CREAT)) == -1)
	{
		perror("msgget");
		exit(1);
	}

	msgctl(msqid, IPC_STAT, &buf);

	printf("the key:%d,\nthe uid:%d, \nthe gid:%d, \nthe cuid:%d, \nthe dgid:%d, \nthe mode:%d,",
        buf.msg_perm.__key, buf.msg_perm.uid, buf.msg_perm.gid, buf.msg_perm.cuid, buf.msg_perm.cgid, buf.msg_perm.mode, buf.msg_perm.__seq);
	printf("the max bytes is :%d\n", buf.msg_qbytes);
	msgctl(msqid, IPC_RMID, (struct msqid_ds *)0);
	return 0;
}

