#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <mqueue.h>

typedef struct mqmsg
{
	mqd_t mqd;		/* 消息队列文件描述符*/
	int prio;		/* 消息队列优先级*/
	int num;		/* 消息队列条数*/
	char error[16];	/* 告警信息*/
}msg_t;

int main()
{
    int flags = 0;
    mqd_t mqd;
    flags = O_RDWR | O_CREAT;
    char *mq_name = "/alarm_tmp";
    struct mq_attr attr;
    long int msgsize = 16;
    long int maxmsg = 8;

    attr.mq_flags = 0;
    attr.mq_msgsize = msgsize;
    attr.mq_maxmsg = maxmsg;

    mqd = mq_open(mq_name, flags, S_IRUSR | S_IWUSR | S_IROTH | S_IRGRP, &attr);
    if(mqd == -1)
    {
       perror("mq_open");
       return 0;
    }

    printf("create success\nMax msgs = %ld, Max byte/msg = %ld\n", attr.mq_maxmsg, attr.mq_msgsize);

    msg_t msg;

    strcpy(msg.error, "somethings");
    msg.mqd = mqd;
    msg.num = 1;
    unsigned int prio = 1;

    int i = 0;
    for(i = 0; i < 50; i++)
    //for(;;)
    {
        //scanf("%s", msg.error);
        mq_send(mqd, msg.error, sizeof(msg.error), msg.prio);
        printf("THE %d send %s to mqd %d\n",i++, msg.error, mqd);
        sleep(2);
    }

    mq_close(mqd);
    mq_unlink(mq_name);
    return 0;

}
