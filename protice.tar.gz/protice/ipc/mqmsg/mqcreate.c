#include <stdio.h>
#include <stdlib.h>
#include <mqueue.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

#define MQ_NAME ("/tmp")
#define MQ_FLAG (O_RDWR | O_CREAT | O_EXCL)
#define FILE_MODE 0666

int main()
{
    mqd_t posixmq;
    int rc = 0;

    posixmq = mq_open(MQ_NAME, MQ_FLAG, FILE_MODE, NULL);

    if(-1 == posixmq)
    {
        perror("create mq failed");
        exit(1);
    }

    rc = mq_close(posixmq);
    if(0 != rc)
    {
        perror("close failed");
        exit(1);
    }
#if 0
    rc = mq_unlink(MQ_NAME);
    if(0 != rc)
    {
        perror("unlink failed");
        exit(1);
    }
#endif
    return 0;
}
