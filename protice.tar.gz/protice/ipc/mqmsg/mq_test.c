#include <stdio.h>
#include <mqueue.h>

#include <string.h>

#define MQ_NAME "/mqfile"
#define MQ_MAXMSG   10
#define MQ_MSGSIZE  20
#define FILE_MODE 0664


mqd_t mq_create(void *name, int maxmsg, int msgsize)
{
    //设置属性
    struct mq_attr attr;

    attr.mq_flags = 0;
    attr.mq_maxmsg = maxmsg;
    attr.mq_msgsize = msgsize;

    mqd_t fd;
    fd = mq_open(name, O_RDWR | O_CREAT | O_EXCL, FILE_MODE, &attr);
    if(-1 == fd)
    {   //只写模式打开消息队列
        fd = mq_open(name, O_RDWR, FILE_MODE, &attr);
        //perror("mq_open error");
        if(-1 == fd)
        return -1;
    }
    //获取属性
    struct mq_attr mqattr;
	if(-1 == mq_getattr(fd, &mqattr))
    {
        perror("mq_getattr error");
        return -1;
    }

    if((mqattr.mq_maxmsg != MQ_MAXMSG) || (mqattr.mq_msgsize != MQ_MSGSIZE))
    {
        if(mq_unlink(MQ_NAME) == -1)
        {
            perror("unlink error");
            return -1;
        }
        fd = mq_open(MQ_NAME, O_RDWR | O_CREAT | O_EXCL, FILE_MODE, &attr);
    }

    return fd;
}




int main()
{
    mqd_t mqfd;
    int maxmag = MQ_MAXMSG;
    int maxsize = MQ_MSGSIZE;
    int prio = 0;
    int i;
    mq_unlink(MQ_NAME);
    mqfd = mq_create(MQ_NAME, MQ_MAXMSG, MQ_MSGSIZE);
    printf("open success\n");
    struct mq_attr attr;
    for(i = 1; i < 50 ; i++)
    {

        mq_getattr(mqfd, &attr);
        printf("mq_curmsgs:%ld\n", attr.mq_curmsgs);
        if(attr.mq_curmsgs > 11)
        {
            char msg[20] = {'\0'};
            mq_receive(mqfd, msg, sizeof(msg), &prio);
            printf("recv %s\n", msg);
        }

        char ptr[20] = {'\0'};

        sprintf(ptr, "send alarm %d", i);

        if(mq_send(mqfd, ptr, MQ_MSGSIZE, prio) == -1)
        {
            perror("mq_send error");
        }
        else
            printf("send %s\n", ptr);
        sleep(1);

    }

    mq_close(mqfd);
    return 0;
}
