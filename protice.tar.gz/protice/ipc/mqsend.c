#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <mqueue.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define MQ_NAME "/alarm_tmp"
#define MQ_FLAG (O_RDWR | O_CREAT | O_EXCL)
#define FILE_MODE 0664
#define MQ_MAXMSG 10
#define MQ_MSGSIZE 36

typedef unsigned int  uint_t;

mqd_t mq_create(void *name, int maxmsg, int msgsize);
int del_msg(mqd_t fd, int num, int size);

int main(int argc,char *argv[])
{
    mqd_t   mqd;
    uint_t  prio;
    int rc;
    prio = 1;
    struct mq_attr attr;
    /*创建消息队列*/
    mqd = mq_create(MQ_NAME, MQ_MAXMSG, MQ_MSGSIZE);
    mq_getattr(mqd, &attr);
	//printf("mq_flags:%ld\n", mqattr.mq_flags);
	//printf("mq_maxmsg:%ld\n", mqattr.mq_maxmsg);
	//printf("mq_msgsize:%ld\n", mqattr.mq_msgsize);
	//
    printf("create success\n");
    printf("Max msgs = %ld\n", attr.mq_maxmsg);
    printf("Max byte/msg = %ld\n", attr.mq_msgsize);
    char ptr[MQ_MSGSIZE] = {'\0'};

    while(1)
    {
        printf("please input 1 or 2 to select send manual or auto\n");
        scanf("%d", &rc);
        atoi(rc);
        if(rc == 1)
        {
            for(;;)
            {
                //超过8条删除第一条
                if(del_msg(mqd, 8, MQ_MSGSIZE) == 1)
                    printf("del success\n");

                bzero(ptr, sizeof(ptr));
                printf("please input some words: ");
                scanf("%s", ptr);
                /*向消息队列写入消息，如消息队列满则阻塞，直到消息队列有空闲时再写入*/
                if(mq_send(mqd, ptr, attr.mq_msgsize, prio) == -1)
                {
                    perror("mq_send error");
                }

            }
        }
        else if(rc == 2)
        {

            int i;
            for(i=1;;i++)
            {
                //超过8条删除第一条
                if(del_msg(mqd, 8, MQ_MSGSIZE) == 1)
                    printf("del success\n");
                //char ptr[MQ_MSGSIZE] = "somethings error";
                sprintf(ptr, "somethings error-%d", i);
                if(mq_send(mqd, ptr, attr.mq_msgsize, prio) == -1)
                {
                    perror("mq_send error");
                }
                else
                    printf("send:%d, %s\n", i, ptr);
                sleep(2);
            }
        }
        else
        {
            printf("input error\n");
            break;
        }


    }

    /*关闭消息队列 mq*/
	rc = mq_close(mqd);
	if(rc != rc)
	{
		perror("mq_close error");
		exit(1);
	}

    return 0;
}


int del_msg(mqd_t fd, int num, int size)
{
    struct mq_attr attr;
    mq_getattr(fd, &attr);
    unsigned int prio;
    printf("mq_curmsgs:%ld\n", attr.mq_curmsgs);
    if(attr.mq_curmsgs > num)
    {
        char *msg = (char*)calloc(1, size);
        if(mq_receive(fd, msg, size, &prio) == -1)
            perror("mq_receive");
        else
        {
            printf("del:%s\n", msg);
            free(msg);
            return 1;
        }

    }

    return 0;
}


mqd_t mq_create(void *name, int maxmsg, int msgsize)
{
    //设置属性
    struct mq_attr attr;

    attr.mq_flags = 0;
    attr.mq_maxmsg = maxmsg;
    attr.mq_msgsize = msgsize;

    mqd_t fd;
    fd = mq_open(name, MQ_FLAG, FILE_MODE, &attr);
    if(-1 == fd)
    {   //只写模式打开消息队列
        fd = mq_open(name, O_RDWR, FILE_MODE, &attr);
        //perror("mq_open error");
        if(-1 == fd)
        return -1;
    }
    //获取属性
    struct mq_attr mqattr;
	if(-1 == mq_getattr(fd, &mqattr))
    {
        perror("mq_getattr error");
        return -1;
    }

    if((mqattr.mq_maxmsg != MQ_MAXMSG) || (mqattr.mq_msgsize != MQ_MSGSIZE))
    {
        if(mq_unlink(MQ_NAME) == -1)
        {
            perror("unlink error");
            return -1;
        }
        fd = mq_open(MQ_NAME, MQ_FLAG, FILE_MODE, &attr);
    }

    return fd;
}
