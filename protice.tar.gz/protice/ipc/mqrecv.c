#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <mqueue.h>
#include <fcntl.h>
#include <errno.h>
#include<sys/stat.h>
typedef unsigned int  uint_t;

int main(int argc,char *argv[])
{
    mqd_t mqd;
    struct mq_attr attr;
    char *ptr;
    unsigned int prio;
    size_t n;
    int rc;

    if(argc != 2)
    {
        printf("Usage: readmq <name> \n");
        exit(1);
    }

    mqd = mq_open(argv[1], O_RDONLY);
    if(mqd < 0)
    {
        perror("mq_open error");
        exit(1);
    }

    rc = mq_getattr(mqd, &attr);
    if(rc < 0)
    {
        perror("取得消息队列属性失败");
        exit(1);
    }

    ptr = calloc(attr.mq_msgsize, sizeof(char));
    if(NULL == ptr)
    {
        printf("calloc error");
    }

    /*接收一条消息*/
    n = mq_receive(mqd, ptr, attr.mq_msgsize, &prio);
    if(n < 0)
    {
        perror("读取失败");
        mq_close(mqd);
        free(ptr);
        exit(1);
    }

    printf("读取 %ld 字节\n  优先级为 %u\n", (long)n, prio);

    return 0;
}
