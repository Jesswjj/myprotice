#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>

typedef struct _msg
{
    long mtype;
    char mtext[50];
}MSG;

int main()
{
    key_t key;
    int msgqid;
    MSG msg;

    key = ftok("./", 2015);

    msgqid = msgget(key, IPC_CREAT|0666);
    if(msgqid == -1)
    {
        perror("msgget");
        exit(-1);
    }

    msg.mtype = 10;
    strcpy(msg.mtext, "hello ih");

    msgsnd(msgqid, &msg, sizeof(msg)-sizeof(long), 0);

    return 0;

}
