#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdlib.h>

typedef struct _msg
{
    long mtype;
    char mtext[50];
}MSG;


int main()
{
    key_t key;

    int msgqid;

    key = ftok("./", 2015);

    msgqid = msgget(key, IPC_CREAT|0666);
    if(msgqid == -1)
    {
        perror("msgget");
        exit(1);
    }

    MSG msg;
    memset(&msg, 0, sizeof(msg));

    msgrcv(msgqid, &msg, sizeof(msg)-sizeof(long), (long)10, 0);
    printf("msg.mtext=%s\n", msg.mtext);

    msgctl(msgqid, IPC_RMID, NULL);

    return 0;
}
