#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>

static int semaphore_v(void);
static int set_semvalue(void);
static int get_semvalue(void);

union semun
{
    int val;
    struct semid_ds *buf;
    unsigned short int *array;
    struct seminfo *__buf;
};

int sem_id;

int main(int argc, char *argv[])
{
    pid_t pid;
    int i;
    int value;
    key_t key;
    int status;

    if((pid = fork()) == -1)
    {
        perror("fork");
        exit(1);
    }
    else if(pid == 0)
    {
        if((sem_id = semget((key_t)12345, 1, IPC_CREAT|0777)) == -1)
        {
            perror("semget");
            exit(1);
        }
        if(!set_semvalue())
        {
            fprintf(stderr, "failed to initialize semaphore\n");
            exit(1);
        }
        value=get_semvalue();
        printf("this is child, the current value is %d\n", value);
        if(!semaphore_v())
        {
            fprintf(stderr, "failed to v operator\n");
            exit(1);
        }
        value = get_semvalue();
        printf("this is child, the current value is %d\n", value);
        if(!semaphore_v())
        {
            fprintf(stderr, "")
        }
    }
}
