#include <mqueue.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

#define MQ_NAME "/alarm_tmp"
#define MQ_FLAG (O_RDWR)
#define FILE_MODE 0660

int main()
{
	mqd_t posixmq;
	int rc = 0;

	/*创建消息队列 mq*/
	posixmq = mq_open(MQ_NAME, MQ_FLAG, FILE_MODE, NULL);
	if(-1 == posixmq)
	{
		perror("mq_open error");
		exit(1);
	}

    struct mq_attr mqattr;
	rc = mq_getattr(posixmq, &mqattr);
	if(-1 == rc)
    {
        perror("mq_getattr error");
        exit(1);
    }
	printf("mq_flags:%ld\n", mqattr.mq_flags);
	printf("mq_maxmsg:%ld\n", mqattr.mq_maxmsg);
	printf("mq_msgsize:%ld\n", mqattr.mq_msgsize);
	printf("mq_curmsgs%ld\n", mqattr.mq_curmsgs);

	/*关闭消息队列 mq*/
	rc = mq_close(posixmq);
	if(rc != rc)
	{
		perror("mq_close error");
		exit(1);
	}
    rc = mq_unlink(MQ_NAME);
    if(rc != rc)
    {
        perror("unlink error");
        exit(1);
    }

    return 0;
}
