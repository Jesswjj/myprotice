#!/bin/sh

expr 3 + 2
echo $?

expr 3 % 2
echo $?

expr 3 \* 2
echo $?

#exit 0
