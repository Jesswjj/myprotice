#!/bin/sh

echo No.0 $0
echo No.1 $1
echo No.2 $2
echo No.3 $3
echo No.4 $4
echo No.5 $5
echo No.6 $6
echo No.7 $7
