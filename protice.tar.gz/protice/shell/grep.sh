#!/bin/sh
# echo -e "\033[34m天蓝字\033[0m"

# out=`cat iptable|grep -c '^[[:digit:]]'`
# echo $out
# if [ "`cat iptable|grep -c '^[[:digit:]]'`" -le "1" ]
# then
#     echo $?
#     echo "le 1 zhen"
# else
#     echo $?
#     echo "le 1 jia"
# fi

localhost='127.0.0.1'

cat iptable|grep -E  "([0-9]{1,3}[\.]){3}[0-9]{1,3}"
# ipcmd='-L INPUT'
# imcd='-nL INPUT --line-number'
# #cat iptable 
# out=`cat iptable|grep -o "$localhost"`
# echo $out
# if  [ "`cat iptable|grep -o "$localhost"`" != "$localhost" ]
# then
#     echo "zhen"
# else
#     echo "jia"
# fi

hostcount=`cat iptable|grep -c "$localhost"`
echo $hostcount
while [ $hostcount -gt 1 ]
do
    hostcount=`expr $hostcount - 1`
    echo $hostcount
done
echo "last $hostcount"