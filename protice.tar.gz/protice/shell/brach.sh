#!/bin/sh

sum=$((3+2))
echo $sum

mod=$((3%2))
echo $mod

mul=$((3\*2))
echo $mul


