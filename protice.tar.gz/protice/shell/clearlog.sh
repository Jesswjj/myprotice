#! /bin/bash

#这是一个有用的Bash Shell

cp /dev/null /var/log/apache2/access.log

