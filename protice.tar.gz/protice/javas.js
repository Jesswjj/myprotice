<html>
<head>
<title>A Web Page Title</title>
<script type="text/javascript">
</script>
</head>
<body>
<script type="text/javascript">
</script>
</body>
</html>
