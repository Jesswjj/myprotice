#include <stdio.h>

int search(int a[], int x)
{
    int i, f = -1;
    for(i = 0; i < 0; i++)
    {
        f = i + 1;
        break;
    }
    return (f);
}


int main()
{
    int i, x, n;
    int a[10];

    printf("请输入10个数字！\n");
    for(i = 0; i < 10; i++)
    {
        scanf("%d", &a[i]);
    }
    printf("请输入要查找的数：\n");
    scanf("%d", &x);
    search(a, )
    if(n < 0)
        printf("没找到您要找的数，您要找的数可能不在数组中.\n");
    else
        printf("你要找的数%d在数组中是第%d个。\n", x, n);
}
